#include <iostream>
#include <functional>

using std::cout;
using std::endl;
using std::bind;

//swap(int x, int y)
//swap(int *px, int *py)
//swap(int &x, int &y)
//a = 3, b = 5
//add(a, b)
//x = a, y = b
int add(int x, int y)
{
    cout << "int add(int, int)" << endl;
    return x + y;
}

class Example
{
public:
    //隐含的this
    int add(int x, int y)
    {
        cout << "int Example::add(int, int)" << endl;
        return x + y;
    }

    int data = 200;//C++11中支持在声明变量的时候进行赋初值

};

void test()
{
    //bind可以改变函数的形态（类型,标签）
    //函数形态：函数的返回类型与参数列表(参数个数、顺序、类型)
    //int(int, int)----->int()
    auto f = bind(add, 1, 3);//原本应该是传函数的地址
    cout << "f() = " << f() << endl;

    Example ex;
    //如果ex生命周期达到了，那么此处就是一个空指针
    /* auto f2 = bind(&Example::add, &ex, 3, 5); */
    auto f2 = bind(&Example::add, ex, 3, 5);//值传递,拷贝操作
    cout << "f2() = " << f2() << endl;

    //int(int, int)---->int(int)
    auto f3 = bind(add, 10, std::placeholders::_1);
    //----
    //----
    cout << "f3(30, 40) = " << f3(30, 40) << endl;
}

//pFunc是一个类型，指向返回类型是int，参数是空的函数
//函数指针
typedef int (*pFunc)();

int func1()
{
    return 1;
}

int func2()
{
    return 5;
}

void func3()
{

}

void test2()
{
    //钩子函数
    //函数指针的一种用法：回调函数
    //延迟调用
    pFunc f =  &func1;//回调函数的注册
    cout << "1111" << endl;
    cout << "2222" << endl;
    cout << "f() = " << f() << endl;//回调函数的执行
    func1();
    cout << "2222" << endl;
    func1();

    f = func2;
    cout << "f() = " << f() << endl;

    /* f = func3;//error */
}

void func4(int x1, int x2, int x3, const int &x4, int x5)
{
    cout << "x1 = " << x1 << endl
         << "x2 = " << x2 << endl
         << "x3 = " << x3 << endl
         << "x4 = " << x4 << endl
         << "x5 = " << x5 << endl;
}

void test3()
{
    int number = 100;
    using namespace std::placeholders;
    //占位符整体代表是形参的位置
    //占位符中的数字代表的是实参的位置
    //默认情况下采用的是值传递
    //std::ref = reference,引用的包装器
    //std::cref = const reference,引用的包装器
    auto f = bind(func4, 1, std::placeholders::_3,
                  std::placeholders::_1, std::cref(number), number);
    number = 200;
    f(10, 20, 50, 70, 90);
}

void test4()
{
    //bind可以改变函数的形态（类型,标签）
    //函数形态：函数的返回类型与参数列表(参数个数、顺序、类型)
    //int(int, int)----->int()
    //function可以看成是函数的容器
    std::function<int()> f = bind(add, 1, 3);//原本应该是传函数的地址
    cout << "f() = " << f() << endl;

    /* vector<int> vec; */

    Example ex;
    //如果ex生命周期达到了，那么此处就是一个空指针
    /* auto f2 = bind(&Example::add, &ex, 3, 5); */
    /* std::function<int()> f2 = bind(&Example::add, ex, 3, 5);//值传递,拷贝操作 */
    f = bind(&Example::add, ex, 3, 5);//值传递,拷贝操作
    cout << "f() = " << f() << endl;

    //int(int, int)---->int(int)
    std::function<int(int)> f3 = bind(add, 10, std::placeholders::_1);
    cout << "f3(30) = " << f3(30) << endl;

    //bind还可以绑定到数据成员
    f = bind(&Example::data, &ex);
    cout << "f() = " << f() << endl;
}
int main(int argc, char **argv)
{
    test4();
    return 0;
}

