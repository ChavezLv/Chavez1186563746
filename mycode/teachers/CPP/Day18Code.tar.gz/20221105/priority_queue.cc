#include <math.h>
#include <iostream>
#include <queue>
#include <vector>

using std::cout;
using std::endl;
using std::priority_queue;
using std::vector;

void test()
{
    //优先级队列底层使用的堆排序（默认情况下是一个大根堆）
    //当有元素插入进来的时候，会去与堆顶进行比较，如果堆顶比插入的元素要
    //小的时候，满足std::less, 新插入的元素就变为新的堆顶,如果堆顶比新插入
    //的元素要大，不满足std::less，此时老的堆顶会成为新的堆顶
    vector<int> vec = {1, 5, 3, 7, 9, 6, 2, 5};
    /* priority_queue<int> pque(vec.begin(), vec.end()); */
    priority_queue<int> pque;

    for(size_t idx = 0; idx != vec.size(); ++idx)
    {
        pque.push(vec[idx]);
        cout << "优先级最高的元素: " << pque.top() << endl;
    }

    cout << endl <<endl;
    while(!pque.empty())
    {
        cout << pque.top() << "  ";
        pque.pop();
    }
    cout << endl;
}

class Point
{
public:
    Point(int ix = 0, int iy = 0)
    : _ix(ix)
    , _iy(iy)
    {
        /* cout << "Point(int = 0, int = 0)" << endl; */
    }

    double getDistance() const
    {
        return hypot(_ix, _iy);
    }

    int getX() const
    {
        return _ix;
    }

    int getY() const
    {
        return _iy;
    }

    ~Point()
    {
        /* cout << "~Point()" << endl; */
    }

    friend std::ostream &operator<<(std::ostream &os, const Point &rhs);
    friend bool operator<(const Point &lhs, const Point &rhs);
    friend struct Comparetion;

private:
    int _ix;
    int _iy;
};

std::ostream &operator<<(std::ostream &os, const Point &rhs)
{
    os << "("  << rhs._ix
       << ", " << rhs._iy
       << ")";

    return os;
}

#if 1
//命名空间是可以进行扩展的
namespace std
{
//模板的特化(全特化)
template <>
struct less<Point>
{
    bool operator()(const Point &lhs, const Point &rhs) const
    {
        /* cout << "bool std::less::operator()(const Point &, const Point &) const"  << endl; */
        if(lhs.getDistance() < rhs.getDistance())
        {
            return true;
        }
        else if(lhs.getDistance() == rhs.getDistance())
        {
            if(lhs.getX() < rhs.getX())
            {
                return true;
            }
            else if(lhs.getX() == rhs.getX())
            {
                if(lhs.getY() < rhs.getY())
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
};

}//end of namespace std

#endif
#if 1
bool operator<(const Point &lhs, const Point &rhs)
{
    /* cout << "bool operator<(const Point &, const Point &)" << endl; */
    if(lhs.getDistance() < rhs.getDistance())
    {
        return true;
    }
    else if(lhs.getDistance() == rhs.getDistance())
    {
        if(lhs._ix < rhs._ix)
        {
            return true;
        }
        else if(lhs._ix == rhs._ix)
        {
            if(lhs._iy < rhs._iy)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
    else
    {
        return false;
    }

}
#endif
#if 1
//函数对象的形式
struct Comparetion
{
    bool operator()(const Point &lhs, const Point &rhs) const
    {
        /* cout << "bool Comparetion::operator()(const Point &, const Point &) const"  << endl; */
        if(lhs.getDistance() < rhs.getDistance())
        {
            return true;
        }
        else if(lhs.getDistance() == rhs.getDistance())
        {
            if(lhs._ix < rhs._ix)
            {
                return true;
            }
            else if(lhs._ix == rhs._ix)
            {
                if(lhs._iy < rhs._iy)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }

    };
};
#endif

void test2()
{
    vector<Point> vec = {
        Point(1, 2),
        Point(1, -2),
        Point(3, 2),
        Point(-1, 2),
        Point(1, 2),
        Point(10, 2),
    };
    /* priority_queue<Point> pque; */
    priority_queue<Point, vector<Point>, Comparetion> pque;

    for(size_t idx = 0; idx != vec.size(); ++idx)
    {
        pque.push(vec[idx]);
        cout << "优先级最高的元素: " << pque.top() << endl;
    }

    cout << endl <<endl;
    while(!pque.empty())
    {
        cout << pque.top() << "  ";
        pque.pop();
    }
    cout << endl;
}
int main(int argc, char **argv)
{
    test2();
    return 0;
}

