#include "trans.h"
#include <iostream>
#include <string>
#include <unordered_map>
#include <fstream>

using namespace std;

int main(int argc, char *argv[])
{
    ifstream readMap("map.txt");
    ifstream readFile("file2.txt");
    trans(readMap, readFile);

    return 0;

}
