#include <iostream>
#include <vector>
#include <list>
#include <set>
#include <algorithm>
#include <iterator>

using std::cout;
using std::endl;
using std::vector;
using std::list;
using std::set;
using std::copy;
using std::ostream_iterator;
using std::back_inserter;
using std::back_insert_iterator;
using std::front_inserter;
using std::front_insert_iterator;
using std::inserter;
using std::insert_iterator;

void test()
{
    vector<int> vecNumber = {1, 5, 9, 7};
    list<int> listNumber = {11, 66, 55, 33};

    //底层会调用push_back函数
    copy(listNumber.begin(), listNumber.end(), 
         back_insert_iterator<vector<int>>(vecNumber));
    /* copy(listNumber.begin(), listNumber.end(), */ 
    /*      back_inserter(vecNumber)); */
    copy(vecNumber.begin(), vecNumber.end(), 
         ostream_iterator<int>(cout, "  "));
    cout << endl;

    cout << endl << endl;
    //底层会调用push_front
    copy(vecNumber.begin(), vecNumber.end(), 
         front_insert_iterator<list<int>>(listNumber));
    /* copy(vecNumber.begin(), vecNumber.end(), */ 
    /*      front_inserter(listNumber)); */
    copy(listNumber.begin(), listNumber.end(), 
         ostream_iterator<int>(cout, "  "));
    cout << endl;

    cout << endl << endl;
    //底层调用insert函数
    set<int> setNumber = {10, 111, 555, 333};
    set<int>::iterator sit = setNumber.begin();
    copy(vecNumber.begin(), vecNumber.end(), 
         insert_iterator<set<int>>(setNumber, sit));
    /* copy(vecNumber.begin(), vecNumber.end(), */ 
    /*      inserter(setNumber, sit)); */
    copy(setNumber.begin(), setNumber.end(), 
         ostream_iterator<int>(cout, "  "));
    cout << endl;
    


}

int main(int argc, char **argv)
{
    test();
    return 0;
}

