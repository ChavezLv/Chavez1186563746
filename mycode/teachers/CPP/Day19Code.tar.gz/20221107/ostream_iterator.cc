#include <iostream>
#include <iterator>
#include <vector>
#include <algorithm>

using std::cout;
using std::endl;
using std::ostream_iterator;
using std::vector;
using std::copy;

//cout << 1 << "\n";
//cout << 3 << "\n";
//operator<<
void test()
{
    vector<int> number = {1, 3, 5, 9, 7};
    ostream_iterator<int> osi(cout, "\n");
    copy(number.begin(), number.end(), osi);
}

int main(int argc, char **argv)
{
    test();
    return 0;
}

