#include <iostream>
#include <functional>

using std::cout;
using std::endl;
using std::bind;

int add(int x, int y)
{
    cout << "int add(int, int)" << endl;
    return x + y;
}

class Example
{
public:
    //隐含的this
    int add(int x, int y)
    {
        cout << "int Example::add(int, int)" << endl;
        return x + y;
    }

};

//函数指针
void test()
{
    //bind可以改变函数的形态（类型,标签）
    //函数形态：函数的名字与参数列表(参数个数、顺序、类型)
    auto f = bind(add, 1, 3);//原本应该是传函数的地址
    cout << "f() = " << f() << endl;

    Example ex;
    auto f2 = bind(&Example::add, &ex, 3, 5);
    cout << "f2() = " << f2() << endl;
}

//pFunc是一个类型，指向返回类型是int，参数也是int的函数
typedef int (*pFunc)();

int func1()
{
    return 1;
}

int func2()
{
    return 5;
}

void func3()
{

}

void test2()
{
    //函数指针的一种用法：回调函数
    //延迟调用
    pFunc f =  &func1;//回调函数的注册
    cout << "1111" << endl;
    cout << "2222" << endl;
    cout << "f() = " << f() << endl;//回调函数的执行
    func1();

    f = func2;
    cout << "f() = " << f() << endl;

    /* f = func3;//error */
}

int main(int argc, char **argv)
{
    test2();
    return 0;
}

