#include <iostream>
#include <algorithm>
#include <vector>
#include <iterator>

using std::cout;
using std::endl;
using std::vector;
using std::remove_if;
using std::for_each;
using std::ostream_iterator;

void print(int value)
{
    cout << value << "  ";
}

bool func(int value)
{
    return value > 5;
}

void test()
{
    vector<int> number = {1, 2, 5, 8, 9, 6, 7, 5, 3};
    for_each(number.begin(), number.end(), print);

    cout << endl;
    auto it = remove_if(number.begin(), number.end(), 
                        std::bind1st(std::less<int>(), 5));
    /* auto it = remove_if(number.begin(), number.end(), */ 
    /*                     std::bind2nd(std::greater<int>(), 5)); */

    /* auto it = remove_if(number.begin(), number.end(), [](int value){ */
    /*                     return value > 5; */
    /*                     }); */

    //remove_if不能直接达到效果，往往需要配合erase使用
    //为了让算法更具有通用性
    /* auto it = remove_if(number.begin(), number.end(), func); */
    number.erase(it, number.end());
    copy(number.begin(), number.end(), 
         ostream_iterator<int>(cout, "  "));
    cout << endl;
}

void test2()
{
    vector<int> number;
    number.push_back(100);

    bool flag = true;
    for(auto it = number.begin(); it != number.end(); ++it)
    {
        cout << *it << "  ";
        if(flag)
        {
            number.push_back(200);//底层发生了扩容,迭代器失效
            flag = false;
            it = number.begin();//重新置位
        }
    }
    cout << endl;
}

int main(int argc, char **argv)
{
    test();
    return 0;
}

