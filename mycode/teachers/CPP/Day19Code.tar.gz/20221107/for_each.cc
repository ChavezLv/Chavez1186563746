#include <iostream>
#include <algorithm>
#include <vector>
#include <iterator>

using std::cout;
using std::endl;
using std::for_each;
using std::vector;
using std::copy;
using std::ostream_iterator;

void func(int &value)
{
    ++value;
    cout << value << "  ";
}

void test()
{
    int a = 10;
    vector<int> number = {1, 5, 8, 9, 7, 5};
    copy(number.begin(), number.end(), 
         ostream_iterator<int>(cout, "  "));
    cout << endl;

    //lambda表达式(匿名函数)
    //[]捕获列表
    //()参数列表
    //void函数的返回类型（可以省略）
    //{}函数体
    /* for_each(number.begin(), number.end(), [a](int &value)mutable->void{ */
    for_each(number.begin(), number.end(), [](int &value){
             ++value;
             /* cout << "a = " << a << endl; */
             cout << value << "  ";
             });

    /* for_each(number.begin(), number.end(), func); */

    cout << endl;
    copy(number.begin(), number.end(), 
         ostream_iterator<int>(cout, "  "));
    cout << endl;
}

void print(int value)
{
    cout << value << "  ";
}

void test2()
{
    vector<int> number = {1, 5, 8, 9, 7, 5};
    for_each(number.begin(), number.end(), print);

    cout << endl << endl;
    size_t cnt = count(number.begin(), number.end(), 5);
    cout << "cnt = " << cnt << endl;

    cout << endl << endl;
    auto it = find(number.begin(), number.end(), 9);
    if(it == number.end())
    {
        cout << "该元素不存在vector中" << endl;
    }
    else
    {
        cout << *it << "  ";
    }
    cout << endl;
}

int main(int argc, char **argv)
{
    test2();
    return 0;
}

