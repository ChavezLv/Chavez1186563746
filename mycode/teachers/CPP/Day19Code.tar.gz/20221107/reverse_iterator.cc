#include <iostream>
#include <iterator>
#include <vector>

using std::cout;
using std::endl;
using std::reverse_iterator;
using std::vector;

void test()
{
    vector<int> number = {1, 5, 8, 9, 6};
    vector<int>::const_iterator cit = number.cbegin(); 
    for(;cit != number.cend(); ++cit)
    {
        cout << *cit << "  ";
    }
    cout << endl;
}

void test2()
{
    vector<int> number = {1, 5, 8, 9, 6};
    vector<int>::reverse_iterator rit = number.rbegin(); 
    for(;rit != number.rend(); ++rit)
    {
        cout << *rit << "  ";
    }
    cout << endl;
}
int main(int argc, char **argv)
{
    test2();
    return 0;
}

