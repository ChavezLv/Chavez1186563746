#include "TaskQueue.h"

TaskQueue::TaskQueue(size_t queSize)
: _queSize(queSize)
, _que()
, _mutex()
, _notEmpty(_mutex)
, _notFull(_mutex)
{

}

TaskQueue::~TaskQueue()
{

}

bool TaskQueue::empty() const
{
    return 0 == _que.size();
}

bool TaskQueue::full() const
{
    return _que.size() == _queSize;
}

void TaskQueue::push(const int &value)
{
    /* _mutex.lock(); */
    //RAII的思想
    MutexLockGuard autoLock(_mutex);

    //虚假唤醒
    /* if(full()) */
    while(full())
    {
        _notFull.wait();//让生产者睡觉
    }

    _que.push(value);
#if 0
    if(//...)
    {
        /* _mutex.unlock(); */
        return ;
    }
#endif

    _notEmpty.notify();

    /* _mutex.unlock(); */
}

int TaskQueue::pop()
{
    /* _mutex.lock(); */
    //RAII的思想
    MutexLockGuard autoLock(_mutex);

    /* if(empty()) */
    while(empty())
    {
        _notEmpty.wait();//让消费者睡觉
    }

    int tmp = _que.front();
    _que.pop();

    _notFull.notify();

    /* _mutex.unlock(); */

    return tmp;
}
