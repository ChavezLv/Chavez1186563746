#include "Producer.h"
#include "Consumer.h"
#include <iostream>
#include <memory>

using std::cout;
using std::endl;
using std::unique_ptr;

int main(int argc, char **argv)
{
    TaskQueue taskQue(10);

    unique_ptr<Thread> pro(new Producer(taskQue));
    unique_ptr<Thread> pro2(new Producer(taskQue));
    unique_ptr<Thread>  con(new Consumer(taskQue));

    pro->start();
    pro2->start();
    con->start();

    pro->stop();
    pro2->stop();
    con->stop();

    //对象语义：不能进行复制与赋值
    //   1、将拷贝构造函数与赋值运算符函数设置为私有
    //   2、将拷贝构造函数与赋值运算符函数=delete
    //值语义：可以进行复制与赋值
    MutexLock mutex1;
    MutexLock mutex2 = mutex1;//拷贝构造函数
    MutexLock mutex3;
    mutex3 = mutex1;//赋值运算符函数
    return 0;
}

