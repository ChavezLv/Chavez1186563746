#include "NonCopyable.h"
#include <iostream>

using std::cout;
using std::endl;


int main(int argc, char **argv)
{
    Example nc1;
    Example nc2 = nc1;//error
    Example nc3;
    nc3 = nc1;//error
    return 0;
}

