#include <iostream>
#include <vector>
#include <deque>
#include <list>

using std::cout;
using std::endl;
using std::vector;
using std::deque;
using std::list;

template <typename Container>
void display(const Container &con)
{
    for(auto &elem : con)
    {
        cout << elem << "  ";
    }
    cout << endl;
}

void test00()
{
    vector<int> number;
    for(int idx = 0; idx < 10000000; ++idx)
    {
        number.push_back(idx);
    }
}

class Point
{
public:
    Point(int ix = 0, int iy = 0)
    : _ix(ix)
    , _iy(iy)
    {
        cout << "Point(int = 0, int = 0)" << endl;
    }

    ~Point()
    {
        cout << "~Point()" << endl;
    }

private:
    int _ix;
    int _iy;
};

void test0()
{
    vector<Point> number;
    number.push_back(Point(1, 2));
    number.emplace_back(1, 2);
}

void test()
{
    cout << "sizeof(vector<int>) = " << sizeof(vector<int>) << endl;
    cout << "sizeof(vector<char>) = " << sizeof(vector<char>) << endl << endl;

    vector<int> number = {1, 3, 5, 7, 9, 10, 2, 4, 6, 8};
    display(number);
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() << endl;

    cout << endl << "在vector的尾部进行插入与删除" << endl;
    number.push_back(22);
    number.push_back(55);
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() << endl;
    display(number);
    number.pop_back();
    display(number);
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() << endl;

    //不允许在头部进行插入与删除的原因？
    //时间复杂度O(N)，因为在头部插入与删除一个元素，会导致
    //所有元素的位置发生变动
    //如何得到vector第一个元素的地址？
    &number;//error
    &number[0];//ok
    &*number.begin();//ok
    int *pdata = number.data();//ok

    cout << endl << "在vector的中间进行插入" << endl;
    /* vector<int>::iterator it = number.begin(); */
    auto it = number.begin();
    ++it;
    ++it;
    cout << "*it = " << *it << endl;
    number.insert(it, 300);
    display(number);
    cout << "*it = " << *it << endl;
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() << endl;

    cout << endl << endl;
    //insert的过程中，vector的底层已经发生了扩容，迭代器指向的是老的空间
    //元素操作的时候在新的空间
    //解决方案：可以在每次使用迭代器的时候，重新置位即可
    number.insert(it, 10, 400);
    display(number);
    cout << "*it = " << *it << endl;
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() << endl;

    cout << endl << endl;
    vector<int> vec = {11, 33, 66, 22};
    it = number.begin();
    number.insert(it, vec.begin(), vec.end());
    display(number);
    cout << "*it = " << *it << endl;
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() << endl;

    cout << endl << endl;
    it = number.begin();
    number.insert(it, {100, 300, 500});
    display(number);
    cout << "*it = " << *it << endl;
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() << endl;

    cout << endl << "vector的清除"<< endl;
    number.clear();//将元素全部清除
    number.shrink_to_fit();//回收多余的空间
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() << endl;
}

void test2()
{
    deque<int> number = {1, 3, 5, 7, 9, 10, 2, 4, 6, 8};
    display(number);

    cout << endl << "在deque的尾部进行插入与删除" << endl;
    number.push_back(22);
    number.push_back(55);
    display(number);
    number.pop_back();
    display(number);

    cout << endl << "在deque的头部进行插入与删除" << endl;
    number.push_front(222);
    number.push_front(555);
    display(number);
    number.pop_front();
    display(number);

    cout << endl << "在deque的中间进行插入" << endl;
    /* deque<int>::iterator it = number.begin(); */
    auto it = number.begin();
    ++it;
    ++it;
    cout << "*it = " << *it << endl;
    number.insert(it, 300);
    display(number);
    cout << "*it = " << *it << endl;

    cout << endl << endl;
    number.insert(it, 4, 400);
    display(number);
    cout << "*it = " << *it << endl;

    cout << endl << endl;
    vector<int> vec = {11, 33, 66, 22};
    number.insert(it, vec.begin(), vec.end());
    display(number);
    cout << "*it = " << *it << endl;

    cout << endl << endl;
    number.insert(it, {100, 300, 500});
    display(number);
    cout << "*it = " << *it << endl;

    cout << endl << "deque的清除"<< endl;
    number.clear();//将元素全部清除
    number.shrink_to_fit();//回收多余的空间
    cout << "number.size() = " << number.size() << endl;
}

void test3()
{
    list<int> number = {1, 3, 5, 7, 9, 10, 2, 4, 6, 8};
    display(number);

    cout << endl << "在list的尾部进行插入与删除" << endl;
    number.push_back(22);
    number.push_back(55);
    display(number);
    number.pop_back();
    display(number);

    cout << endl << "在list的头部进行插入与删除" << endl;
    number.push_front(222);
    number.push_front(555);
    display(number);
    number.pop_front();
    display(number);

    cout << endl << "在list的中间进行插入" << endl;
    list<int>::iterator it = number.begin();
    ++it;
    ++it;
    cout << "*it = " << *it << endl;
    number.insert(it, 300);
    display(number);
    cout << "*it = " << *it << endl;

    cout << endl << endl;
    number.insert(it, 5, 400);
    display(number);
    cout << "*it = " << *it << endl;

    cout << endl << endl;
    vector<int> vec = {11, 33, 66, 22};
    number.insert(it, vec.begin(), vec.end());
    display(number);
    cout << "*it = " << *it << endl;

    cout << endl << endl;
    number.insert(it, {100, 300, 500});
    display(number);
    cout << "*it = " << *it << endl;

    cout << endl << "list的清除"<< endl;
    number.clear();//将元素全部清除
    cout << "number.size() = " << number.size() << endl;
}

int main(int argc, char **argv)
{
    cout << "测试vector" << endl;
    test();

    cout << endl << "测试deque"<< endl;
    test2();

    cout << endl << "测试list"<< endl;
    test3();
    return 0;
}

