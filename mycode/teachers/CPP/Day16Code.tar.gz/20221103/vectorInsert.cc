#include <iostream>
#include <vector>

using std::cout;
using std::endl;
using std::vector;

template <typename Container>
void display(const Container &con)
{
    for(auto &elem : con)
    {
        cout << elem << "  ";
    }
    cout << endl;
}

void test()
{
    vector<int> number = {1, 3, 5, 7, 9, 10, 2, 4, 6, 8};
    display(number);
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() << endl;

    cout << endl << "在vector的中间进行插入" << endl;
    auto it = number.begin();
    ++it;
    ++it;
    cout << "*it = " << *it << endl;
    number.insert(it, 300);
    display(number);
    cout << "*it = " << *it << endl;
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() << endl;

    //size() = m, capacity() = n, 插入的元素的个数t
    //1、t < n - m, 插入元素的个数比剩余空间少，不会扩容
    //2、n - m < t < m, 按照2 * m扩容
    //3、n - m < t, m < t < n，按照m + t进行扩容
    //4、t > n,按照 m + t进行扩容
    cout << endl << endl;
    it = number.begin();
    number.insert(it, 60, 400);
    display(number);
    cout << "*it = " << *it << endl;
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() << endl;

    cout << endl << endl;
    vector<int> vec = {11, 33, 66, 22};
    it = number.begin();
    number.insert(it, vec.begin(), vec.end());
    display(number);
    cout << "*it = " << *it << endl;
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() << endl;
}

int main(int argc, char **argv)
{
    test();
    return 0;
}

