#include <iostream>
#include <vector>
#include <deque>
#include <list>

using std::cout;
using std::endl;
using std::vector;
using std::deque;
using std::list;

void test()
{
    /* int arr[10]; */
    //初始化
    //1、count个value
    /* vector<int> number(10, 1); */
    //2、迭代器范围
    /* int arr[10] = {1, 2, 5, 7, 9, 8, 7, 6, 5, 4}; */
    /* vector<int> number(arr, arr + 10);//[,)，左闭右开 */
    //3、大括号的形式
    vector<int> number = {1, 3, 5, 7, 9, 2, 4, 6, 8, 10};
    //4、空
    //5、拷贝构造函数与移动构造函数

    //遍历
    //1、下标
    for(size_t idx = 0; idx != number.size(); ++idx)
    {
        cout << number[idx] << "  ";
    }
    cout << endl;

    //2、迭代器
    //迭代器可以看成是泛型的执行
    vector<int>::iterator it;
    for(it = number.begin(); it != number.end(); ++it)
    {
        cout << *it << "  ";
    }
    cout << endl;

    //3、迭代器（初始化）
    vector<int>::iterator it2 = number.begin();
    for(; it2 != number.end(); ++it2)
    {
        cout << *it2 << "  ";
    }
    cout << endl;

    //4、for与auto结合
    for(auto &elem : number)
    {
        cout << elem << "  ";
    }
    cout << endl;
}

void test2()
{
    /* int arr[10]; */
    //初始化
    //1、count个value
    deque<int> number(10, 1);
    //2、迭代器范围
    /* int arr[10] = {1, 2, 5, 7, 9, 8, 7, 6, 5, 4}; */
    /* deque<int> number(arr, arr + 10);//[,)，左闭右开 */
    //3、大括号的形式
    /* deque<int> number = {1, 3, 5, 7, 9, 2, 4, 6, 8, 10}; */
    //4、空
    //5、拷贝构造函数与移动构造函数

    //遍历
    //1、下标
    for(size_t idx = 0; idx != number.size(); ++idx)
    {
        cout << number[idx] << "  ";
    }
    cout << endl;

    //2、迭代器
    //迭代器可以看成是泛型的执行
    deque<int>::iterator it;
    for(it = number.begin(); it != number.end(); ++it)
    {
        cout << *it << "  ";
    }
    cout << endl;

    //3、迭代器（初始化）
    deque<int>::iterator it2 = number.begin();
    for(; it2 != number.end(); ++it2)
    {
        cout << *it2 << "  ";
    }
    cout << endl;

    //4、for与auto结合
    for(auto &elem : number)
    {
        cout << elem << "  ";
    }
    cout << endl;
}

void test3()
{
    /* int arr[10]; */
    //初始化
    //1、count个value
    /* list<int> number(10, 1); */
    //2、迭代器范围
    /* int arr[10] = {1, 2, 5, 7, 9, 8, 7, 6, 5, 4}; */
    /* list<int> number(arr, arr + 10);//[,)，左闭右开 */
    //3、大括号的形式
    list<int> number = {1, 3, 5, 7, 9, 2, 4, 6, 8, 10};
    //4、空
    //5、拷贝构造函数与移动构造函数

    //遍历
#if 0
    //1、下标
    for(size_t idx = 0; idx != number.size(); ++idx)
    {
        cout << number[idx] << "  ";
    }
    cout << endl;
#endif

    //2、迭代器
    //迭代器可以看成是泛型的执行
    list<int>::iterator it;
    for(it = number.begin(); it != number.end(); ++it)
    {
        cout << *it << "  ";
    }
    cout << endl;

    //3、迭代器（初始化）
    list<int>::iterator it2 = number.begin();
    for(; it2 != number.end(); ++it2)
    {
        cout << *it2 << "  ";
    }
    cout << endl;

    //4、for与auto结合
    for(auto &elem : number)
    {
        cout << elem << "  ";
    }
    cout << endl;
}
int main(int argc, char **argv)
{
    test3();
    return 0;
}

