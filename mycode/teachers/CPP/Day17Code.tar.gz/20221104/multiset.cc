#include <math.h>
#include <iostream>
#include <set>
#include <vector>

using std::cout;
using std::endl;
using std::multiset;
using std::vector;

template <typename Container>
void display(const Container &con)
{
    for(auto &elem : con)
    {
        cout << elem << "  ";
    }
    cout << endl;
}

void test()
{
    //multiset的特征
    //1、key值是不唯一的，可以重复
    //2、默认情况下，会按照key值进行升序排列
    //3、multiset的底层实现使用的是红黑树
    multiset<int> number = {1, 4, 7, 9, 7, 7, 8, 7, 5, 2, 6};
    display(number);

    cout << endl << "multiset的查找操作" << endl;
    size_t cnt1 = number.count(7);
    size_t cnt2 = number.count(10);
    cout << "cnt1 = " << cnt1 << endl;
    cout << "cnt2 = " << cnt2 << endl;

    cout << endl << endl;
    multiset<int>::iterator it = number.find(17);
    /* auto it = number.find(7); */
    if(it == number.end())
    {
        cout << "该元素不存在multiset中" << endl;
    }
    else
    {
        cout << "*it = " << *it << endl;
    }

    cout << endl << "测试bound函数" << endl;
    auto it2 = number.lower_bound(7);
    cout << "*it2 = " << *it2 << endl;

    auto it3 = number.upper_bound(7);
    cout << "*it3 = " << *it3 << endl;

    while(it2 != it3)
    {
        cout << *it2 << "  ";
        ++it2;
    }
    cout << endl;

    std::pair<multiset<int>::iterator, multiset<int>::iterator> 
        ret = number.equal_range(7);
    while(ret.first != ret.second)
    {
        cout << *ret.first << "  ";
        ++ret.first;
    }
    cout << endl;

    cout << endl << "multiset的insert操作" << endl;
    number.insert(3);
    display(number);

    cout << endl << endl;
    vector<int> vec = {11, 66, 99, 33};
    number.insert(vec.begin(), vec.end());
    display(number);

    cout <<endl <<endl;
    number.insert({3, 20, 39});
    display(number);

    cout << endl << "multiset的删除操作" << endl;
    it = number.begin();
    ++it;
    number.erase(it);
    display(number);

    cout << endl << "multiset的下标操作" << endl;
    /* cout << "number[1] = " << number[1] << endl; */

    cout << endl << "multiset的修改操作" << endl;
    it = number.begin();
    ++it;
    cout << "*it = " << *it <<endl;
    /* *it = 300;//error */
}

class Point
{
public:
    Point(int ix = 0, int iy = 0)
    : _ix(ix)
    , _iy(iy)
    {
        /* cout << "Point(int = 0, int = 0)" << endl; */
    }

    double getDistance() const
    {
        return hypot(_ix, _iy);
    }

    int getX() const
    {
        return _ix;
    }

    int getY() const
    {
        return _iy;
    }

    ~Point()
    {
        /* cout << "~Point()" << endl; */
    }

    friend std::ostream &operator<<(std::ostream &os, const Point &rhs);
    friend bool operator<(const Point &lhs, const Point &rhs);
    friend struct Comparetion;

private:
    int _ix;
    int _iy;
};

std::ostream &operator<<(std::ostream &os, const Point &rhs)
{
    os << "("  << rhs._ix
       << ", " << rhs._iy
       << ")";

    return os;
}

#if 1
//命名空间是可以进行扩展的
namespace std
{
//模板的特化(全特化)
template <>
struct less<Point>
{
    bool operator()(const Point &lhs, const Point &rhs) const
    {
        cout << "bool std::less::operator()(const Point &, const Point &) const"  << endl;
        if(lhs.getDistance() < rhs.getDistance())
        {
            return true;
        }
        else if(lhs.getDistance() == rhs.getDistance())
        {
            if(lhs.getX() < rhs.getX())
            {
                return true;
            }
            else if(lhs.getX() == rhs.getX())
            {
                if(lhs.getY() < rhs.getY())
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
};

}//end of namespace std

#endif
#if 1
bool operator<(const Point &lhs, const Point &rhs)
{
    cout << "bool operator<(const Point &, const Point &)" << endl;
    if(lhs.getDistance() < rhs.getDistance())
    {
        return true;
    }
    else if(lhs.getDistance() == rhs.getDistance())
    {
        if(lhs._ix < rhs._ix)
        {
            return true;
        }
        else if(lhs._ix == rhs._ix)
        {
            if(lhs._iy < rhs._iy)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
    else
    {
        return false;
    }

}
#endif
#if 1
//函数对象的形式
struct Comparetion
{
    bool operator()(const Point &lhs, const Point &rhs) const
    {
        cout << "bool Comparetion::operator()(const Point &, const Point &) const"  << endl;
        if(lhs.getDistance() < rhs.getDistance())
        {
            return true;
        }
        else if(lhs.getDistance() == rhs.getDistance())
        {
            if(lhs._ix < rhs._ix)
            {
                return true;
            }
            else if(lhs._ix == rhs._ix)
            {
                if(lhs._iy < rhs._iy)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }

    };
};
#endif

void test2()
{
    /* multiset<Point> number = { */
    /* multiset<Point, std::greater<Point>> number = { */
    multiset<Point, Comparetion> number = {
        Point(1, 2),
        Point(1, -2),
        Point(-1, 2),
        Point(1, 2),
        Point(3, 4),
        Point(-3, 14),
    };
    display(number);
}

int main(int argc, char **argv)
{
    test2();
    return 0;
}

