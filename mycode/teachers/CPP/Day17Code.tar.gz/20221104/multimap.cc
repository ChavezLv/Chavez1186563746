#include <math.h>
#include <iostream>
#include <map>
#include <string>
#include <utility>

using std::cout;
using std::endl;
using std::multimap;
using std::string;
using std::make_pair;

template <typename Container>
void display(const Container &con)
{
    for(auto &elem : con)
    {
        cout << elem.first  << "  " << elem.second << endl;
    }
}

void test()
{
    //multimap的特征
    //1、存储的是key-value类型，key值是不唯一的，可以重复,
    //value是可以相同的
    //2、默认情况下，会按照key值进行升序排列
    //3、底层实现使用的是红黑树
    multimap<int, string> number = {
        std::pair<int, string>(1, "hello"),
        std::pair<int, string>(3, "hello"),
        {2, "wuhan"},
        {2, "wuhan"},
        {4, "beijing"},
        std::make_pair(5, "nanjing"),
        std::make_pair(3, "nanjing"),
    };
    display(number);

    cout << endl << "multimap的查找操作" << endl;
    size_t cnt1 = number.count(2);
    size_t cnt2 = number.count(10);
    cout << "cnt1 = " << cnt1 << endl;
    cout << "cnt2 = " << cnt2 << endl;

    cout << endl << endl;
    multimap<int, string>::iterator it = number.find(17);
    /* auto it = number.find(7); */
    if(it == number.end())
    {
        cout << "该元素不存在multimap中" << endl;
    }
    else
    {
        cout << it->first << "  "<< it->second << endl;
    }

    cout << endl << "multimap的insert操作" << endl;
    /* number.insert(std::pair<int, string>(7, "beijing")); */
    /* number.insert({7, "beijing"}); */
    number.insert(std::make_pair(7, "beijing"));
    display(number);

#if 0
    cout << endl << "multimap的下标访问" << endl;
    cout << "number[3] = " << number[3] << endl;//查找
    cout << "number[6] = " << number[6] << endl;//插入
    display(number);

    cout << endl << endl;
    number[6] = "wangdao";
    number[3] = "wangdao";//修改
    //T &operator[](Key)
    //{
    //   return T;
    //}
    display(number);
#endif
}

class Point
{
public:
    Point(int ix = 0, int iy = 0)
    : _ix(ix)
    , _iy(iy)
    {
        /* cout << "Point(int = 0, int = 0)" << endl; */
    }

    double getDistance() const
    {
        return hypot(_ix, _iy);
    }

    int getX() const
    {
        return _ix;
    }

    int getY() const
    {
        return _iy;
    }

    ~Point()
    {
        /* cout << "~Point()" << endl; */
    }

    friend std::ostream &operator<<(std::ostream &os, const Point &rhs);

private:
    int _ix;
    int _iy;
};

std::ostream &operator<<(std::ostream &os, const Point &rhs)
{
    os << "("  << rhs._ix
       << ", " << rhs._iy
       << ")";

    return os;
}

void test2()
{
    multimap<string, Point> number = {
        std::pair<string, Point>("1", Point(1, 2)),
        std::pair<string, Point>("3", Point(3, 2)),
        { "4", Point(4, 5) },
        { "2", Point(4, 5) },
        std::make_pair("3", Point(3, 2)),
        std::make_pair("6", Point(3, 2)),
    };
    display(number);

#if 0
    cout << endl << "multimap的下标访问" << endl;
    cout << "number[\"1\"] = " << number["1"] << endl;
    cout << "number[\"5\"] = " << number["5"] << endl;
    display(number);

    cout <<endl <<endl;
    number["5"] = Point(3, 6);
    number.operator[]("5").operator=(Point(3, 6));
    display(number);
#endif

}

int main(int argc, char **argv)
{
    test();
    return 0;
}

