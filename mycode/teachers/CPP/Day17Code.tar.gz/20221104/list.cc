#include <iostream>
#include <list>

using std::cout;
using std::endl;
using std::list;

template <typename Container>
void display(const Container &con)
{
    for(auto &elem : con)
    {
        cout << elem << "  ";
    }
    cout << endl;
}

//函数对象
template <typename T>
struct Com
{
    bool operator()(const T &lhs, const T &rhs) const
    {
        cout << "bool Com::operator(const T &, const T &) const" << endl;
        return lhs < rhs;
    }
};

void test()
{
    list<int> number = {1, 3, 9, 5, 4, 8, 5, 7, 2, 4, 5, 9};
    display(number);

    cout << endl << "list的unique操作" << endl;
    number.unique();
    display(number);

    cout << endl << "list的sort操作" << endl;
    number.sort();
    /* std::less<int> lt; */
    /* number.sort(lt); */
    /* number.sort(std::less<int>()); */
    /* number.sort(std::greater<int>()); */
    /* number.sort(Com<int>()); */
    display(number);

    cout << endl << "list的unique操作" << endl;
    number.unique();
    display(number);

    cout << endl << "list的reverse操作"<< endl;
    number.reverse();
    display(number);

    cout << endl << "list的merge操作"<< endl;
    list<int> number2 = {19, 6, 11, 13};
    number.sort();
    number2.sort();//先排序
    /* number2.sort(std::greater<int>());//先排序 */
    number.merge(number2);
    display(number);
    display(number2);

    cout << endl << "list的splice操作"<< endl;
    list<int> number3 = {100, 600, 500, 300};
    auto it = number.begin();
    ++it;
    number.splice(it, number3);
    display(number);
    display(number3);

    cout << endl << endl;
    list<int> number4 = {111, 555, 444, 333, 222, 999};
    auto it2 = number4.begin();
    number.splice(it, number4, it2);
    display(number);
    display(number4);

    cout << endl << endl;
    it2 = number4.begin();
    auto it3 = number4.end();
    --it3;
    --it3;
    cout << "*it2 = " << *it2 << endl;
    cout << "*it3 = " << *it3 << endl;
    number.splice(it, number4, it2, it3);
    display(number);
    display(number4);

    cout << endl << endl;
    auto it4 = number.begin();
    ++it4;
    ++it4;
    auto it5 = number.end();
    --it5;
    --it5;
    cout << "*it4 = " << *it4 << endl;
    cout << "*it5 = " << *it5 << endl;
    number.splice(it4, number, it5);
    display(number);

}

int main(int argc, char **argv)
{
    test();
    return 0;
}

