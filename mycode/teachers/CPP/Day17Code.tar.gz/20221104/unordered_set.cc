#include <math.h>
#include <iostream>
#include <unordered_set>

using std::cout;
using std::endl;
using std::unordered_set;

template <typename Container>
void display(const Container &con)
{
    for(auto &elem : con)
    {
        cout << elem << "  ";
    }
    cout << endl;
}

void test()
{
    //unordered_set的特征
    //1、key值是唯一的，不能重复
    //2、key值是没有顺序的
    //3、底层使用的是哈希
    unordered_set<int> number = {1, 3, 5, 9, 7, 5, 8, 2, 6};
    display(number);
}

class Point
{
public:
    Point(int ix = 0, int iy = 0)
    : _ix(ix)
    , _iy(iy)
    {
        /* cout << "Point(int = 0, int = 0)" << endl; */
    }

    double getDistance() const
    {
        return hypot(_ix, _iy);
    }

    int getX() const
    {
        return _ix;
    }

    int getY() const
    {
        return _iy;
    }

    ~Point()
    {
        /* cout << "~Point()" << endl; */
    }

    friend std::ostream &operator<<(std::ostream &os, const Point &rhs);

private:
    int _ix;
    int _iy;
};

std::ostream &operator<<(std::ostream &os, const Point &rhs)
{
    os << "("  << rhs._ix
       << ", " << rhs._iy
       << ")";

    return os;
}

namespace  std
{
template <>
struct hash<Point>
{
    size_t operator()(const Point &rhs) const
    {
        cout << "size_t std::hash::operator()(const Point &) const" << endl;
        return (rhs.getX() << 2) ^ (rhs.getY() << 1);
    };
};

}//end of namespace std

struct HashPoint
{
    size_t operator()(const Point &rhs) const
    {
        cout << "size_t HashPoint::operator()(const Point &) const" << endl;
        return (rhs.getX() << 2) ^ (rhs.getY() << 1);
    };

};



//对于equal_to的三种等价形式
bool operator==(const Point &lhs, const Point &rhs)
{
    cout << "bool operator==(const Point &, const Point &)" << endl;
    return (lhs.getX() == rhs.getX()) && (lhs.getY() == rhs.getY());
}

namespace  std
{
template <>
struct equal_to<Point>
{
    bool operator()(const Point &lhs, const Point &rhs) const
    {
        cout << "bool equal_to::operator()(const Point &, const Point &)" << endl;
        return (lhs.getX() == rhs.getX()) && (lhs.getY() == rhs.getY());
    }

};

}//end of namespace std

struct HashEqualTo
{
    bool operator()(const Point &lhs, const Point &rhs) const
    {
        cout << "bool HashEqualT::operator()(const Point &, const Point &)" << endl;
        return (lhs.getX() == rhs.getX()) && (lhs.getY() == rhs.getY());
    }

};

void test2()
{
    /* unordered_set<Point> number = { */
    unordered_set<Point, HashPoint, HashEqualTo> number = {
        Point(1, 2),
        Point(1, -2),
        Point(3, 4),
        Point(-1, 2),
        Point(1, 2),
        Point(5, 4),
    };
    display(number);
}
int main(int argc, char **argv)
{
    test2();
    return 0;
}

