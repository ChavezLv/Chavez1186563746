#include <math.h>
#include <iostream>
#include <set>
#include <vector>

using std::cout;
using std::endl;
using std::set;
using std::vector;

template <typename Container>
void display(const Container &con)
{
    for(auto &elem : con)
    {
        cout << elem << "  ";
    }
    cout << endl;
}

void test()
{
    //set的特征
    //1、key值是唯一的，不能重复
    //2、默认情况下，会按照key值进行升序排列
    //3、set的底层实现使用的是红黑树
    set<int> number = {1, 4, 7, 9, 8, 7, 5, 2, 6};
    display(number);

    cout << endl << "set的查找操作" << endl;
    size_t cnt1 = number.count(1);
    size_t cnt2 = number.count(10);
    cout << "cnt1 = " << cnt1 << endl;
    cout << "cnt2 = " << cnt2 << endl;

    cout << endl << endl;
    set<int>::iterator it = number.find(17);
    /* auto it = number.find(7); */
    if(it == number.end())
    {
        cout << "该元素不存在set中" << endl;
    }
    else
    {
        cout << "*it = " << *it << endl;
    }

    cout << endl << "set的insert操作" << endl;
    std::pair<set<int>::iterator, bool> ret = number.insert(3);
    if(ret.second)
    {
        cout << "插入成功" << *ret.first << endl;
    }
    else
    {
        cout << "插入失败，该元素存在set中" << endl;
    }

    cout << endl << endl;
    vector<int> vec = {11, 66, 99, 33};
    number.insert(vec.begin(), vec.end());
    display(number);

    cout <<endl <<endl;
    number.insert({3, 20, 39});
    display(number);

    cout << endl << "set的删除操作" << endl;
    it = number.begin();
    ++it;
    number.erase(it);
    display(number);

    cout << endl << "set的下标操作" << endl;
    /* cout << "number[1] = " << number[1] << endl; */

    cout << endl << "set的修改操作" << endl;
    it = number.begin();
    ++it;
    cout << "*it = " << *it <<endl;
    /* *it = 300;//error */
}

class Point
{
public:
    Point(int ix = 0, int iy = 0)
    : _ix(ix)
    , _iy(iy)
    {
        /* cout << "Point(int = 0, int = 0)" << endl; */
    }

    double getDistance() const
    {
        return hypot(_ix, _iy);
    }

    int getX() const
    {
        return _ix;
    }

    int getY() const
    {
        return _iy;
    }

    ~Point()
    {
        /* cout << "~Point()" << endl; */
    }

    friend std::ostream &operator<<(std::ostream &os, const Point &rhs);
    friend bool operator<(const Point &lhs, const Point &rhs);
    friend struct Comparetion;

private:
    int _ix;
    int _iy;
};

std::ostream &operator<<(std::ostream &os, const Point &rhs)
{
    os << "("  << rhs._ix
       << ", " << rhs._iy
       << ")";

    return os;
}

#if 1
//命名空间是可以进行扩展的
namespace std
{
//模板的特化(全特化)
template <>
struct less<Point>
{
    bool operator()(const Point &lhs, const Point &rhs) const
    {
        cout << "bool std::less::operator()(const Point &, const Point &) const"  << endl;
        if(lhs.getDistance() < rhs.getDistance())
        {
            return true;
        }
        else if(lhs.getDistance() == rhs.getDistance())
        {
            if(lhs.getX() < rhs.getX())
            {
                return true;
            }
            else if(lhs.getX() == rhs.getX())
            {
                if(lhs.getY() < rhs.getY())
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
};

}//end of namespace std

#endif
#if 1
bool operator<(const Point &lhs, const Point &rhs)
{
    cout << "bool operator<(const Point &, const Point &)" << endl;
    if(lhs.getDistance() < rhs.getDistance())
    {
        return true;
    }
    else if(lhs.getDistance() == rhs.getDistance())
    {
        if(lhs._ix < rhs._ix)
        {
            return true;
        }
        else if(lhs._ix == rhs._ix)
        {
            if(lhs._iy < rhs._iy)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
    else
    {
        return false;
    }

}
#endif
#if 1
//函数对象的形式
struct Comparetion
{
    bool operator()(const Point &lhs, const Point &rhs) const
    {
        cout << "bool Comparetion::operator()(const Point &, const Point &) const"  << endl;
        if(lhs.getDistance() < rhs.getDistance())
        {
            return true;
        }
        else if(lhs.getDistance() == rhs.getDistance())
        {
            if(lhs._ix < rhs._ix)
            {
                return true;
            }
            else if(lhs._ix == rhs._ix)
            {
                if(lhs._iy < rhs._iy)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }

    };
};
#endif

void test2()
{
    set<Point> number = {
    /* set<Point, std::greater<Point>> number = { */
    /* set<Point, Comparetion> number = { */
        Point(1, 2),
        Point(1, -2),
        Point(-1, 2),
        Point(1, 2),
        Point(3, 4),
        Point(-3, 14),
    };
    display(number);
}

int main(int argc, char **argv)
{
    test2();
    return 0;
}

