#include <string.h>
#include <iostream>

using std::cout;
using std::endl;

class String
{
public:
    String()
    : _pstr(nullptr)
    {
        cout << "String()" << endl;
    }

    String(const char *pstr)
    : _pstr(new char[strlen(pstr) + 1]())
    {
        cout << "String(const char *)" << endl;
        strcpy(_pstr, pstr);
    }

    String(const String &rhs)
    : _pstr(new char[strlen(rhs._pstr) + 1]())
    {
        cout << "String(const String &)" << endl;
        strcpy(_pstr, rhs._pstr);
    }

    String &operator=(const String &rhs)
    {
        cout << "String &operator=(const String &)" << endl;
        if(this != &rhs)
        {
            delete [] _pstr;
            _pstr = nullptr;

            _pstr = new char[strlen(rhs._pstr) + 1]();
            strcpy(_pstr, rhs._pstr);
        }

        return *this;
    }

    //String s2 = String("world")
    //移动构造函数
    String(String &&rhs)
    : _pstr(rhs._pstr)
    {
        cout << "String(String &&)" << endl;
        rhs._pstr = nullptr;
    }

    //移动赋值函数
    //s3 = String("wangdao")
    String &operator=(String &&rhs)
    {
        cout << "String &operator=(String &&)" << endl;
        if(this != &rhs)//1、自移动
        {
            delete [] _pstr;
            _pstr = nullptr;

            _pstr = rhs._pstr;
            rhs._pstr = nullptr;
        }

        return *this;
    }

    ~String()
    {
        cout << "~String()" << endl;
        if(_pstr)
        {
            delete [] _pstr;
            _pstr = nullptr;
        }
    }

    friend std::ostream &operator<<(std::ostream &os, const String &rhs);
private:
    char *_pstr;
};

std::ostream &operator<<(std::ostream &os, const String &rhs)
{
    if(rhs._pstr)
    {
        os << rhs._pstr;
    }

    return os;
}

void test()
{
    String s1("hello");
    cout << "s1 = " << s1 << endl;

    cout << endl;
    String s2 = s1;
    cout << "s1 = " << s1 << endl;
    cout << "s2 = " << s2 << endl;

    cout << endl;
    String s3 = "world";//String("world");
    cout << "s3 = " << s3 << endl;

    /* &"world";//左值，位于文件常量区 */
    /* &String("world");//error,右值 */

    cout << endl;
    s3 = String("wangdao");
    cout << "s3 = " << s3 << endl;

    cout << endl << endl;
    String("world") = String("world");

    cout << endl << "s2 = std::move(s2)" << endl;
    s2 = std::move(s2);//std::move其实上什么都没有移动走，只是对
                       //s2做了一个强制转换，static_cast<T &&>(lvalue)
                       //表名以后不想使用这个左值了
    cout << "s2 = " << s2 << endl;
    cout << "111" << endl;

    s3 = std::move(s2);
    cout << "s3 = " << s3 << endl;
    cout << "s2 = " << s2 << endl;
    cout << "222" << endl;

    s2 = "welcome";
    cout << "s2 = " << s2 << endl;
}
int main(int argc, char **argv)
{
    test();
    return 0;
}

