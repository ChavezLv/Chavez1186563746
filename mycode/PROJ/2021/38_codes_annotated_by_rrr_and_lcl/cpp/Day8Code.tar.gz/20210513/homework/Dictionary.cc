#include <time.h>
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <algorithm>

using std::cout;
using std::endl;
using std::string;
using std::vector;
using std::ifstream;
using std::ofstream;
using std::istringstream;
using std::sort;

struct Record
{
    Record(const string &word, int fre)
    : _word(word)
    , _frequency(fre)
    {

    }
    string _word;
    int _frequency;
};

bool operator<(const Record &lhs, const Record &rhs)
{
    return lhs._word < rhs._word;
}
class Dictionary
{
public:
    Dictionary(int capa)
    {
        _dict.reserve(capa);
    }
    void read(const std::string &filename);
    void store(const std::string &filename);
    string dealWord(const string &word);
    void insert(const string &word);
private:
    vector<Record> _dict;
};

void Dictionary::read(const std::string &filename)
{
    ifstream ifs(filename);
    if(!ifs)
    {
        std::cerr << "open " << filename << " error"<< endl;
        return;
    }

    string line;
    while(getline(ifs, line))
    {
        istringstream iss(line);
        string word;
        while(iss >> word)
        {
            string newWord = dealWord(word);//处理非法单词
            insert(newWord);
        }
    }

    sort(_dict.begin(), _dict.end());

    ifs.close();
}
void Dictionary::store(const std::string &filename)
{
    ofstream ofs(filename);
    if(!ofs)
    {
        std::cerr << "ostream is not good" << endl;
        return;
    }

    for(size_t idx = 0; idx != _dict.size(); ++idx)
    {
        ofs << _dict[idx]._word << "   " << _dict[idx]._frequency << endl;
    }

    ofs.close();
}

string Dictionary::dealWord(const string &word)
{
    for(size_t idx = 0; idx != word.size(); ++idx)
    {
        if(!isalpha(word[idx]))//abc123
        {
            return string();//返回的是临时对象
        }
    }

    return word;
}

void Dictionary::insert(const string &word)
{
    if(word == string())
    {
        return;
    }

    size_t idx  = 0;
    for(idx = 0; idx != _dict.size(); ++idx)
    {
        if(word == _dict[idx]._word)
        {
            ++_dict[idx]._frequency;
            break;//当单词词频统计之后，就不需要进行循环操作了
        }
    }

    if(idx == _dict.size())
    {
        _dict.push_back(Record(word, 1));
    }

}
int main(int argc, char **argv)
{
    Dictionary dictionary(13000);
    cout << "start reading...." << endl;
    time_t beg = time(NULL);
    dictionary.read("The_Holy_Bible.txt");
    time_t end = time(NULL);
    cout << "cost " << (end - beg) << "s" << endl;
    cout << "finish reading...." << endl;
    dictionary.store("dic.dat");
    return 0;
}

