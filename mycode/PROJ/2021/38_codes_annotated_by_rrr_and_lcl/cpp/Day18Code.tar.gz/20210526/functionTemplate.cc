#include <string.h>
#include <stdlib.h>
#include <iostream>

using std::cout;
using std::endl;

          //参数类型推导
//函数模板================= 模板函数
//         实例化
//实例化：显示实例化和隐式实例化
//函数模板
/* template <typename T> */
template <class T>//模板参数列表
T add(T x, T y)
{
    cout << "T add(T, T)" << endl;
    return x + y;
}

template <class T>//模板参数列表
T add(T x, T y, T z)
{
    cout << "T add(T, T, T)" << endl;
    return x + y + z;
}

#if 0
int add(int x, int y)
{
    cout << "int add(int, int)" << endl;
    return x + y;
}

double add(double x, double y)
{
    cout << "double add(double , double)" << endl;
    return x + y;
}

float add(float x, float y)
{
    return x + y;
}
#endif

//模板的特化
//模板的全特化和偏特化(部分特化)
//函数模板只支持全特化，不支持偏特化
//类模板既支持全特化，也支持偏特化
template <>
const char *add(const char *px, const char *py)
{
    cout << "const char *add(const char *, const char *)" << endl;
    size_t len =  strlen(px) + strlen(py) + 1;
    char *pTemp = (char *) malloc(len);
    memset(pTemp, 0, len);
    strcpy(pTemp, px);
    strcat(pTemp, py);


    return pTemp;
    
}
void test()
{
    int ia = 3, ib = 4;
    double da = 3.3, db = 4.4;
    char ca = 'a', cb = 1;

    const char *pstr1 = "hello";
    const char *pstr2 = "world";

    cout << "add(ia, ib) = " << add(ia, ib) << endl;//隐式实例化
    cout << "add(da, db) = " << add<double>(da, db) << endl;//显示实例化
    cout << "add(ca, cb) = " << add(ca, cb) << endl;
    /* cout << "add(ia, db) = " << add(ia, db) << endl;//error,ia会推导T为int，db会推导T为double，所以就矛盾 */

    cout << "add(pstr1, pstr2) = " << add(pstr1, pstr2) << endl;
}
int main(int argc, char **argv)
{
    test();
    return 0;
}

