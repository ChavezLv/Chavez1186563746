#include <iostream>

using std::cout;
using std::endl;


//模板的参数类型
//1、类型参数 T
//2、非类型参数  整型,bool/char/short/int/long/size_t
//
template <typename T = int, short kMin = 10>
T multiply(T x, T y)
{
    return x * y * kMin;
}
int main(int argc, char **argv)
{
    int ia = 10, ib = 20;
    cout << "multiply(ia, ib) = " << multiply(ia, ib) << endl;
    cout << "multiply<int,5>(ia, ib) = " << multiply<int, 5>(ia, ib) << endl;
    return 0;
}

