#include "add.h"
#include <iostream>

using std::cout;
using std::endl;

int main(int argc, char **argv)
{
    int ia = 3, ib = 4;
    cout << "add(ia, ib) = " << add(ia, ib) << endl;
    return 0;
}

