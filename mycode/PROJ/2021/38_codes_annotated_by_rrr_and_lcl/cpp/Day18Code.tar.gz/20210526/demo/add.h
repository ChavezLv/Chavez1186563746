#ifndef __ADD_H__
#define __ADD_H__

//模板不能分成头文件与实现文件的形式，在声明的时候必须要看到实现
//
template <class T>
T add(T x, T y);

#include "add.cc"
#endif
