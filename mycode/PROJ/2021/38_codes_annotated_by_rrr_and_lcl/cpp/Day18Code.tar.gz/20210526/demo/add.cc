/* #include "add.h" */

template <class T>
T add(T x, T y)
{
    return  x + y;
}
