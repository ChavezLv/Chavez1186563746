#include <iostream>
#include <vector>
#include <deque>
#include <list>

using std::cout;
using std::endl;
using std::vector;
using std::deque;
using std::list;

template <typename Container>
void display(const Container &c)
{
    for(auto &elem : c)
    {
        cout << elem << "  ";
    }
    cout << endl;
}

class Point
{
public:
    Point(int ix = 0, int iy = 0)
    : _ix(ix)
    , _iy(iy)
    {
        cout << "Point(int = 0, int = 0)" << endl;
    }
private:
    int _ix;
    int _iy;
};
void test00()
{
    vector<Point> number;
    number.push_back(Point(1, 2));
    number.push_back({1, 2});
    number.emplace_back(1, 2);

}
void test()
{
    cout << "sizeof(vector<int>) = " << sizeof(vector<int>) << endl;
    cout << "sizeof(vector<double>) = " << sizeof(vector<double>) << endl << endl;
    cout << "sizeof(vector<char>) = " << sizeof(vector<char>) << endl << endl;

    vector<int> number = {1, 3, 5, 9, 8, 7, 5, 3, 2, 4};
    display(number);
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() <<endl;

    cout << endl << "在vector的尾部进行插入与删除" << endl;
    number.push_back(12);
    number.push_back(6);
    display(number);
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() <<endl;
    number.shrink_to_fit();
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() <<endl;
    number.pop_back();
    display(number);
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() <<endl;

    &number;//获取不到第一个元素的地址，只能获取_M_start的地址
    &number[0];//获取第一个元素的地址
    &*number.begin();//ok
    //vector为何不支持在头部进行插入与删除？时间复杂度O(N)
    

    cout << endl << "在vector中间去进行插入" << endl;
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() <<endl;
    auto it = number.begin();
    ++it;
    ++it;
    cout << "*it = " << *it << endl;
    number.insert(it, 100);
    display(number);
    cout << "*it = " << *it << endl;
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() <<endl;

    cout << endl;
    cout << "*it = " << *it << endl;
    number.insert(it, 20, 200);
    display(number);
    cout << "*it = " << *it << endl;
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() <<endl;

    cout << endl;
    int arr[5] = {1, 6, 9, 8, 7};
    it = number.begin();
    ++it;
    ++it;
    cout << "*it = " << *it << endl;
    number.insert(it, arr, arr + 5);
    display(number);
    cout << "*it = " << *it << endl;
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() <<endl;

    cout << endl << "vector清空元素" << endl;
    number.clear();
    number.shrink_to_fit();//缩减内存
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() <<endl;

}

void test2()
{
    deque<int> number = {1, 3, 5, 9, 8, 7, 5, 3, 2, 4};
    display(number);
    cout << "number.size() = " << number.size() << endl;

    cout << endl << "在deque的尾部进行插入与删除" << endl;
    number.push_back(12);
    number.push_back(6);
    display(number);
    cout << "number.size() = " << number.size() << endl;
    number.pop_back();
    display(number);
    cout << "number.size() = " << number.size() << endl;

    cout << endl << "在deque的头部进行插入与删除" << endl;
    number.push_front(34);
    number.push_front(10);
    display(number);
    cout << "number.size() = " << number.size() << endl;
    number.pop_front();
    display(number);
    cout << "number.size() = " << number.size() << endl;

    cout << endl << "在deque中间去进行插入" << endl;
    auto it = number.begin();
    ++it;
    ++it;
    cout << "*it = " << *it << endl;
    number.insert(it, 100);
    display(number);
    cout << "*it = " << *it << endl;
    cout << "number.size() = " << number.size() << endl;

    cout << endl;
    cout << "*it = " << *it << endl;
    number.insert(it, 3, 200);
    display(number);
    cout << "*it = " << *it << endl;
    cout << "number.size() = " << number.size() << endl;

    cout << endl;
    int arr[5] = {1, 6, 9, 8, 7};
    cout << "*it = " << *it << endl;
    number.insert(it, arr, arr + 5);
    display(number);
    cout << "*it = " << *it << endl;
    cout << "number.size() = " << number.size() << endl;

    cout << endl << "deque清空元素" << endl;
    number.clear();
    number.shrink_to_fit();
    cout << "number.size() = " << number.size() << endl;
}

void test3()
{
    list<int> number = {1, 3, 5, 9, 8, 7, 5, 3, 2, 4};
    display(number);
    cout << "number.size() = " << number.size() << endl;

    cout << endl << "在list的尾部进行插入与删除" << endl;
    number.push_back(12);
    number.push_back(6);
    display(number);
    cout << "number.size() = " << number.size() << endl;
    number.pop_back();
    display(number);
    cout << "number.size() = " << number.size() << endl;

    cout << endl << "在list的头部进行插入与删除" << endl;
    number.push_front(20);
    number.push_front(0);
    display(number);
    cout << "number.size() = " << number.size() << endl;
    number.pop_front();
    display(number);
    cout << "number.size() = " << number.size() << endl;

    cout << endl << "在list中间去进行插入" << endl;
    auto it = number.begin();
    ++it;
    ++it;
    cout << "*it = " << *it << endl;
    number.insert(it, 100);
    display(number);
    cout << "*it = " << *it << endl;
    cout << "number.size() = " << number.size() << endl;

    cout << endl;
    cout << "*it = " << *it << endl;
    number.insert(it, 3, 200);
    display(number);
    cout << "*it = " << *it << endl;
    cout << "number.size() = " << number.size() << endl;

    cout << endl;
    int arr[5] = {1, 6, 9, 8, 7};
    cout << "*it = " << *it << endl;
    number.insert(it, arr, arr + 5);
    display(number);
    cout << "*it = " << *it << endl;
    cout << "number.size() = " << number.size() << endl;

    cout << endl << "list清空元素" << endl;
    number.clear();
    cout << "number.size() = " << number.size() << endl;


}
int main(int argc, char **argv)
{
    test();

    cout << endl << "测试deque" <<endl << endl;
    test2();

    cout << endl << "测试list" <<endl << endl;
    test3();
    return 0;
}

