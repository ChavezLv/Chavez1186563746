#include <iostream>
#include <list>

using std::cout;
using std::endl;
using std::list;

template <typename Container>
void display(const Container &c)
{
    for(auto &elem : c)
    {
        cout << elem << "  ";
    }
    cout << endl;
}
#if 1
template <typename T>
struct Comparetion
{
    bool operator()(const T &lhs, const T &rhs) const
    {
        cout << "bool operator()(const T &, const T &)" << endl;
        return lhs < rhs;
    }
};
#endif
#if 0
bool operator<(const list &lhs, const list &rhs)
{
    cout << "bool operator<(const list<int> &, const list <int>) " << endl;
    return lhs < rhs;
}
#endif
void test()
{
    list<int> number = {1, 3, 5, 7, 1, 3, 8, 2, 4, 6, 3};
    display(number);
    number.unique();//uniqe去重的时候，保证元素是有序的
    display(number);

    cout << endl << "测试sort函数" << endl;
    /* number.sort(std::less<int>()); */
    /* number.sort(std::greater<int>()); */
    /* number.sort(Comparetion<int>()); */
    number.sort();
    display(number);

    cout << endl << "链表的逆置reverse" << endl;
    number.reverse();
    display(number);

    //链表合并的时候，也要保证链表有序
    cout << endl << "链表的合并merge" << endl;
    number.sort(std::less<int>());
    display(number);
    list<int> number2 = {10, 40, 30, 5};
    number2.sort();
    display(number2);
    number.merge(number2);
    display(number);
    display(number2);

    cout << endl << "去除重复元素unique" << endl;
    number.unique();
    display(number);


    cout << endl << "移动元素splice" << endl;
    list<int> number3 = {5, 8, 19, 30, 4, 7};
    display(number3);
    auto it = number.begin();
    ++it;
    ++it;
    /* number.splice(it, number3); */
    /* display(number); */
    /* display(number3); */

    auto it2 = number3.begin();
    ++it2;
    ++it2;
    number.splice(it, number3, it2);
    display(number);
    display(number3);

    cout << endl << endl;
    it2 = number3.begin();
    auto it3 = number3.begin();
    ++it3;
    ++it3;
    cout << "*it = " << *it <<endl;
    number.splice(it, number3, it2, it3);
    display(number);
    display(number3);

    cout << endl << "在同一个链表中进行splice" << endl;
    auto it4 = number.begin();
    auto it5 = number.end();
    auto it6 = number.end();
    ++it4;
    ++it4;
    --it5;
    --it5;
    --it5;
    --it6;
    cout << "it4 = " << *it4 << endl;
    cout << "it5 = " << *it5 << endl;
    cout << "it6 = " << *it6 << endl;
    number.splice(it4, number, it5, it6);
    display(number);
}
int main(int argc, char **argv)
{
    test();
    return 0;
}

