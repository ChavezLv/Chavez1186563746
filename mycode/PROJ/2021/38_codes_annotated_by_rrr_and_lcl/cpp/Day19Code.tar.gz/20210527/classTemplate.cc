#include <iostream>
#include <string>

using std::cout;
using std::endl;
using std::string;

//类模板
template <typename T, size_t kSize = 10>
class Stack
{
public:
    Stack()
    : _top(-1)
    , _data(new T[kSize]())
    {

    }
    ~Stack();
    bool empty() const;
    bool full() const;
    void push(const T &t);
    void pop();
    T top() const;
private:
    int _top;
    T *_data;
};

template <typename T, size_t kSize>
Stack<T, kSize>::~Stack()
{
    if(_data)
    {
        delete [] _data;
        _data = nullptr;
    }
}

template <typename T, size_t kSize>
bool Stack<T, kSize>::empty() const
{
    return -1 == _top;
}

template <typename T, size_t kSize>
bool Stack<T, kSize>::full() const
{
    return _top == kSize - 1;
}

template <typename T, size_t kSize>
void Stack<T,kSize>::push(const T &t)
{
    if(!full())
    {
        _data[++_top] = t;
    }
    else
    {
        cout << "The stack is full" << endl;
        return;
    }
}

template <typename T, size_t kSize>
void Stack<T, kSize>::pop()
{
    if(!empty())
    {
        --_top;
    }
    else
    {
        cout << "The stack is empty" << endl;
        return;
    }
}
template <typename T, size_t kSize>
T Stack<T, kSize>::top() const
{
    return _data[_top];
}

void test()
{
    Stack<int, 15> st;
    cout << "栈是不是空的? " << st.empty() << endl;
    st.push(1);
    cout << "栈是不是满的? " << st.full() << endl;

    for(size_t idx = 2; idx != 20; ++idx)
    {
        st.push(idx);
    }

    while(!st.empty())
    {
        cout << st.top() << "  ";
        st.pop();
    }
    cout << endl;
    cout << "栈是不是空的? " << st.empty() << endl;
}

void test2()
{
    Stack<string> st;
    cout << "栈是不是空的? " << st.empty() << endl;
    st.push(string("aa"));
    cout << "栈是不是满的? " << st.full() << endl;

    for(size_t idx = 1; idx != 20; ++idx)
    {
        st.push(string(2, 'a' + idx));
    }

    while(!st.empty())
    {
        cout << st.top() << "  ";
        st.pop();
    }
    cout << endl;
    cout << "栈是不是空的? " << st.empty() << endl;
}
int main(int argc, char **argv)
{
    test2();
    return 0;
}

