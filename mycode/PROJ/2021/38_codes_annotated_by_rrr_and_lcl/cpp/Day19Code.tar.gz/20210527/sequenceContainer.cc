#include <iostream>
#include <vector>
#include <deque>
#include <list>

using std::cout;
using std::endl;
using std::vector;
using std::deque;
using std::list;

void test()
{
    //初始化
    /* vector<int> number;//1、创建空对象 */
    /* vector<int> number(10, 1);//2、初始化count个value */
    /* int arr[10] = {1, 5, 7, 9, 4, 6, 8, 2, 1, 20}; */
    /* vector<int> number(arr, arr + 10);//3、迭代器范围,[arr, arr + 10) */
    vector<int> number = {1, 5, 7, 9, 4, 6, 2, 1, 20};//4、大括号

    //遍历
    for(size_t idx = 0; idx != number.size(); ++idx)
    {
        cout << number[idx] << "  ";
    }
    cout << endl;

    vector<int>::iterator it;
    for(it = number.begin(); it != number.end(); ++it)
    {
        cout <<*it << "  ";
    }
    cout << endl;

    auto it2 = number.begin();
    for(; it2 != number.end(); ++it2)
    {
        cout <<*it2 << "  ";
    }
    cout << endl;

    for(auto &elem :number)
    {
        cout << elem << "  ";
    }
    cout << endl;

}

void test2()
{
    //初始化
    /* deque<int> number;//1、创建空对象 */
    /* deque<int> number(10, 10);//2、初始化count个value */
    /* int arr[10] = {1, 5, 7, 9, 4, 6, 8, 2, 1, 20}; */
    /* deque<int> number(arr, arr + 10);//3、迭代器范围,[arr, arr + 10) */
    deque<int> number = {1, 5, 7, 9, 4, 6, 2, 1, 20};//4、大括号

    //遍历
    for(size_t idx = 0; idx != number.size(); ++idx)
    {
        cout << number[idx] << "  ";
    }
    cout << endl;

    deque<int>::iterator it;
    for(it = number.begin(); it != number.end(); ++it)
    {
        cout <<*it << "  ";
    }
    cout << endl;

    auto it2 = number.begin();
    for(; it2 != number.end(); ++it2)
    {
        cout <<*it2 << "  ";
    }
    cout << endl;

    for(auto &elem :number)
    {
        cout << elem << "  ";
    }
    cout << endl;

}

void test3()
{
    //初始化
    /* list<int> number;//1、创建空对象 */
    /* list<int> number(10, 10);//2、初始化count个value */
    /* int arr[10] = {1, 5, 7, 9, 4, 6, 8, 2, 1, 20}; */
    /* list<int> number(arr, arr + 10);//3、迭代器范围,[arr, arr + 10) */
    list<int> number = {1, 5, 7, 9, 4, 6, 2, 1, 20};//4、大括号

    //遍历
    //list不支持下标访问
#if 0
    for(size_t idx = 0; idx != number.size(); ++idx)
    {
        cout << number[idx] << "  ";
    }
    cout << endl;
#endif

    list<int>::iterator it;
    for(it = number.begin(); it != number.end(); ++it)
    {
        cout <<*it << "  ";
    }
    cout << endl;

    auto it2 = number.begin();
    for(; it2 != number.end(); ++it2)
    {
        cout <<*it2 << "  ";
    }
    cout << endl;

    for(auto &elem :number)
    {
        cout << elem << "  ";
    }
    cout << endl;

}
int main(int argc, char **argv)
{
    test3();
    return 0;
}

