#include "add.h"
#include <iostream>

using std::cout;
using std::endl;

int main(int argc, char **argv)
{
    int a = 3, b = 4;
    cout << "add(a, b) = " << add(a, b) << endl;
    return 0;
}

