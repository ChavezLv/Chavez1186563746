#include <iostream>
#include <algorithm>
#include <vector>
#include <iterator>

using std::cout;
using std::endl;
using std::vector;
using std::ostream_iterator;
using std::copy;
using std::count;
using std::find;

bool func(int val)
{
    return val > 5;
}
void test()
{
    vector<int> number = {1, 3, 7, 9, 4, 3, 6, 5, 2};
    copy(number.begin(), number.end(), ostream_iterator<int>(cout, "  "));
    cout << endl;

    /* auto it = remove_if(number.begin(), number.end(), func); */
    /* auto it = remove_if(number.begin(), number.end(), [](int val){ */
    /*                     return val > 5; */
    /*                     }); */

    /* auto it = remove_if(number.begin(), number.end(), bind1st(std::less<int>(), 5)); */
    auto it = remove_if(number.begin(), number.end(), bind2nd(std::greater<int>(), 5));
    number.erase(it, number.end());
    copy(number.begin(), number.end(), ostream_iterator<int>(cout, "  "));
    cout << endl;
}

void test2()
{
    vector<int> number;
    number.push_back(1);

    bool flag = true;
    for(auto it = number.begin(); it != number.end(); ++it)
    {
        cout << *it << "  ";
        if(flag)
        {
            number.push_back(2);//底层已经发生了扩容
            flag = false;
            it = number.begin();
            /* ++it; */
        }
        cout << endl;
    }
}
int main(int argc, char **argv)
{
    test();
    return 0;
}

