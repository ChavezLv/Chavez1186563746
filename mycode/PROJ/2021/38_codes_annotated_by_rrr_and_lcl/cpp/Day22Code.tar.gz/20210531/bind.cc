#include <iostream>
#include <functional>

using std::cout;
using std::endl;
using std::bind;

int add(int x, int y)
{
    cout << "int add(int, int)" << endl;
    return x + y;
}

int multiply(int x, int y)
{
    return x * y;
}

class Test
{
public:
    int add(int x, int y)
    {
        cout << "int Test::add(int, int)" << endl;
        return x + y;
    }

    static 
    int func(int x)
    {
        return x;
    }

    int data = 100;//可以进行初始化

};
void test()
{
    //int (int, int)    ====> int ()
    //int ()
    /* auto f = bind(add, 1, 4); */
    //函数的容器
    std::function<int()> f = bind(add, 1, 4);
    cout << "f() = " << f() << endl;

    Test tst;
    //int ()
    auto f1 = bind(&Test::add, &tst, 4, 5); 
    cout << "f1() = " << f1() << endl;

    /* auto f2 = bind(&Test::func, 6); */
    std::function<int()> f2 = bind(&Test::func, 6);
    cout << "f2() = " << f2() << endl;


    cout << endl;
    f2 = bind(&Test::data, &tst);
    cout << "f2(100) = " << f2() << endl;

    //占位符
    //int (int, int)   ==== >
    /* auto f3 = bind(add, 1, std::placeholders::_1); */
    // int (int, int)
    // int (int, int)
    /* auto f3 = bind(add, std::placeholders::_2, std::placeholders::_1); */
    std::function<int(int, int)> f3 = bind(add, std::placeholders::_2, std::placeholders::_1);
    cout << "f3(45) = " << f3(45, 2) << endl;

    f3 = bind(multiply, std::placeholders::_1, std::placeholders::_2);
    cout << "f3(10, 20) = " << f3(10, 20) << endl;
}

typedef int (*pFunc)();

int func2()
{
    return 10;
}

int func3()
{
    return 20;
}

int func4(int x)
{
    return x;
}

void test2()
{
    pFunc f = &func2;//注册回调函数,钩子函数
    cout << "f() = " << f() << endl;//执行回调函数

    f = func3;
    cout << "f() = " << f() << endl;

    /* f = func4;//error */
}

void func5(int x1, int x2, int x3, const int &x4, int x5)
{
    cout << "x1 = " << x1 << endl
         << "x2 = " << x2 << endl
         << "x3 = " << x3 << endl
         << "x4 = " << x4 << endl
         << "x5 = " << x5 << endl;

}

void test3()
{
    //占位符本身表明的是形参的位置
    //占位符中数字参数代表函数传递进来的第几个参数
    //cref =  const reference,引用的包装器
    int number = 400;
    auto f = bind(func5, 1, std::placeholders::_2, 
                  std::placeholders::_4, std::cref(number), number);
    number = 300;
    /* f(12, 34); */
    f(12, 34, 45, 67, 89, 123, 4567);//多余的参数没有任何意义

}
int main(int argc, char **argv)
{
    test();
    return 0;
}

