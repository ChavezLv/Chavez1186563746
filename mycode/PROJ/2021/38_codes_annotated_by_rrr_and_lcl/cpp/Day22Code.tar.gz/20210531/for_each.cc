#include <iostream>
#include <algorithm>
#include <vector>
#include <iterator>

using std::cout;
using std::endl;
using std::for_each;
using std::vector;
using std::ostream_iterator;
using std::copy;
using std::count;
using std::find;

void print(int &val)
{
    ++val;
    cout << val << "  ";
}
void test()
{
    vector<int> number = {1, 4, 7, 9, 3, 2};
    /* for_each(number.begin(), number.end(), print); */
    //lambda表达式，匿名函数，C++11提出来的
    for_each(number.begin(), number.end(), [](int &val){
             ++val;
             cout << val << "  ";
             });
    cout << endl;
    copy(number.begin(), number.end(), ostream_iterator<int>(cout, "  "));
    cout << endl;


    cout << endl;
    size_t cnt1 = count(number.begin(), number.end(), 3);
    cout << "cnt1 = " << cnt1 << endl;

    auto it = find(number.begin(), number.end(), 7);
    if(it == number.end())
    {
        cout << "该元素不存在vector中" << endl;
    }
    else
    {
        cout << *it << "  ";
    }
    cout << endl;

    sort(number.begin(), number.end());
    copy(number.begin(), number.end(), ostream_iterator<int>(cout, "  "));
    cout << endl;
}
int main(int argc, char **argv)
{
    test();
    return 0;
}

