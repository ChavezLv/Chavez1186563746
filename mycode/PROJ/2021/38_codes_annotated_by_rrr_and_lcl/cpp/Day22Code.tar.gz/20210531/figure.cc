#include <math.h>
#include <iostream>
#include <functional>

using std::cout;
using std::endl;
using std::function;

//function + bind实现多态
class Figure
{
public:
    /* typedef function<void()> DisplayCallback;//C语言typedef */

    using DisplayCallback = function<void()>;
    using AreaCallback = function<double ()>;

    DisplayCallback _displayCallback;
    AreaCallback _areaCallback;

    //注册回调函数
    void setDisplayCallback(DisplayCallback &&cb)
    {
        _displayCallback = std::move(cb);
    }

    void setAreaCallback(AreaCallback &&cb)
    {
        _areaCallback = std::move(cb);
    }

    //执行回调函数
    void handDisplayCallback() const
    {
        if(_displayCallback)
        {
            _displayCallback();
        }
    }

    double handAreaCallback() const
    {
        if(_areaCallback)
        {
            _areaCallback();
        }
        else
        {
            return 0;
        }
    }
#if 0
    void display() const = 0;//纯虚函数，作为接口存在，具体实现交给派生类去完成

    virtual 
    double area() const = 0; 
#endif
};


class Rectangle
{
public:
    Rectangle(double length, double width)
    : _length(length)
    , _width(width)
    {

    }

    void display(int x) const
    {
        cout << "Rectangle";
    }

    double area() const 
    {
        return _length * _width;
    }
private:
    double _length;
    double _width;
};

class Circle
{
public:
    Circle(double radis)
    : _radis(radis)
    {

    }

    void display() const 
    {
        cout << "Circle";
    }

    double area() const 
    {
        return _radis * _radis * 3.1415;
    }
private:
    double _radis;
};

class Traingle
{
public:
    Traingle(double a, double b, double c)
    : _a(a)
    , _b(b)
    , _c(c)
    {

    }

    void displayTri() const 
    {
        cout << "Traingle";
    }

    //海伦公式
    double areaTri() const 
    {
        double tmp = (_a + _b + _c)/2;

        return sqrt(tmp * (tmp - _a) * (tmp - _b) * (tmp - _c));
    }
private:
    double _a;
    double _b;
    double _c;
};

void func(const Figure &fig)
{
    fig.handDisplayCallback();
    cout << "'s area is : " << fig.handAreaCallback() << endl;
}

int main(int argc, char **argv)
{
    Rectangle rectangle(10, 20);
    Circle circle(10);
    Traingle traingle(3, 4, 5);

    Figure fig;
    fig.setDisplayCallback(std::bind(&Rectangle::display, &rectangle, 10));
    fig.setAreaCallback(std::bind(&Rectangle::area, &rectangle));
    func(fig);

    fig.setDisplayCallback(std::bind(&Circle::display, &circle));
    fig.setAreaCallback(std::bind(&Circle::area, &circle));
    func(fig);

    fig.setDisplayCallback(std::bind(&Traingle::displayTri, &traingle));
    fig.setAreaCallback(std::bind(&Traingle::areaTri, &traingle));
    func(fig);



    return 0;
}
