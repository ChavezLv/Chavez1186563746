#include <iostream>

using std::cout;
using std::endl;

class Base
{
public:
    Base(long base = 0)
    : _base(base)
    {
        cout << "Base(long = 0)" << endl;
    }

    virtual 
    void print()
    {
        cout << "Base::_base = " << _base  << endl;
    }

    ~Base()
    {
        cout << "~Base()" << endl;
    }
private:
    long _base;
};
class Derived
: public Base
{
public:
    Derived(long base = 0, long derived = 0)
    : Base(base)
    , _derived(derived)
    {
        cout << "Derived(long = 0)" << endl;
    }

    /* void print();//从基类吸收过来的 */
    void print()
    {
        cout << "Derived::_derived = "  << _derived <<  endl;
    }

    ~Derived()
    {
        cout << "~Derived()" << endl;
    }
private:
    long _derived;
};

void func(Base *pbase)
{
    pbase->print();//对于同一指令，针对不同对象，产生不一样的行为
}

int main(int argc, char **argv)
{
    cout << "sizeof(Base) = " << sizeof(Base) << endl;
    cout << "sizeof(Derived) = " << sizeof(Derived) << endl << endl;

    Base base(10);
    base.print();
    Derived derived(22, 33);
    derived.print();

    cout << endl << endl;
    func(&base);
    func(&derived);
    return 0;
}

