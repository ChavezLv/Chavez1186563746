#include <iostream>
#include <memory>

using std::cout;
using std::endl;
using std::auto_ptr;


void test()
{
    //原生指针（裸指针）
    int *pInt = new int(10);
    auto_ptr<int> ap(pInt);
    cout << "*ap = " << *ap << endl;
    cout << "ap.get() = " << ap.get() << endl;
    cout << "pInt = " << pInt << endl;

    cout << endl;
    auto_ptr<int> ap2(ap);//表面上执行了拷贝构造函数，但是底层已经
                         //发生了所有权的转移，这个智能指针存在缺陷
    cout << "*ap2 = " << *ap2 << endl;
    cout << "*ap = " << *ap << endl;
    cout << "1111" << endl;
}
int main(int argc, char **argv)
{
    test();
    return 0;
}

