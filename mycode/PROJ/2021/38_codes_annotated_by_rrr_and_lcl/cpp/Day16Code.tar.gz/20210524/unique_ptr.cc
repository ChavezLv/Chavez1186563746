#include <iostream>
#include <memory>
#include <vector>

using std::cout;
using std::endl;
using std::unique_ptr;
using std::vector;

class Point
{
public:
    Point(int ix = 0, int iy = 0)
    : _ix(ix)
    , _iy(iy)
    {
        cout << "Point(int = 0, int = 0)" << endl;
    }

    void print()
    {
        cout << "_ix = " << _ix << endl
             << "_iy = " << _iy << endl;
    }
    ~Point()
    {
        cout << "~Point()" << endl;
    }
private:
    int _ix;
    int _iy;
};

void test()
{
    //原生指针（裸指针）
    int *pInt = new int(10);
    unique_ptr<int> up(pInt);
    cout << "*up = " << *up << endl;
    cout << "up.get() = " << up.get() << endl;
    cout << "pInt = " << pInt << endl;

    cout << endl;
    /* unique_ptr<int> up2(up);//error,不支持拷贝操作 */

    cout << endl;
    unique_ptr<int> up3(new int(20));
    /* up3 = up;//error,不允许赋值操作 */

    cout << endl;
    unique_ptr<Point> up4(new Point(10, 20));
    vector<unique_ptr<Point>> vec;
    /* vec.push_back(up4);//errror */
    vec.push_back(std::move(up4));
    vec.push_back(unique_ptr<Point>(new Point(1, 3)));

    cout << endl;
    Point *pt = new Point(1, 2);
    vector<Point *> number;//不建议使用裸指针
    /* number.push_back(new Point(1, 2)); */
    number.push_back(pt);
    delete pt;


}
int main(int argc, char **argv)
{
    test();
    return 0;
}

