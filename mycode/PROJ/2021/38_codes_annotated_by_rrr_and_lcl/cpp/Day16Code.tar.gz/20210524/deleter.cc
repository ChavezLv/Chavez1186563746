#include <iostream>
#include <memory>
#include <string>

using std::cout;
using std::endl;
using std::unique_ptr;
using std::shared_ptr;
using std::string;

struct FILEClose
{
    void operator()(FILE *fp)
    {
        cout << "fclose()" << endl;
        fclose(fp);
    }
};
void test()
{
    string msg = "hello,world\n";
    unique_ptr<FILE, FILEClose> up(fopen("wuhan.txt", "a+"));
    fwrite(msg.c_str(), 1, msg.size(), up.get());
    /* fclose(up.get()); */
}


void test2()
{
    /* FILEClose fc; */
    string msg = "hello,world\n";
    /* shared_ptr<FILE> sp(fopen("wd.txt", "a+"), fc); */
    shared_ptr<FILE> sp(fopen("wd.txt", "a+"), FILEClose());
    fwrite(msg.c_str(), 1, msg.size(), sp.get());
}

int main(int argc, char **argv)
{
    test2();
    return 0;
}

