#include <iostream>
#include <memory>
#include <vector>

using std::cout;
using std::endl;
using std::shared_ptr;
using std::vector;

class Point
{
public:
    Point(int ix = 0, int iy = 0)
    : _ix(ix)
    , _iy(iy)
    {
        cout << "Point(int = 0, int = 0)" << endl;
    }

    void print()
    {
        cout << "_ix = " << _ix << endl
             << "_iy = " << _iy << endl;
    }
    ~Point()
    {
        cout << "~Point()" << endl;
    }
private:
    int _ix;
    int _iy;
};

void test()
{
    //原生指针（裸指针）
    int *pInt = new int(10);
    shared_ptr<int> sp(pInt);
    cout << "*sp = " << *sp << endl;
    cout << "sp.get() = " << sp.get() << endl;
    cout << "pInt = " << pInt << endl;
    cout << "sp.use_count() = " << sp.use_count() << endl;

    cout << endl;
    shared_ptr<int> sp2(sp);
    cout << "*sp2 = " << *sp2 << endl;
    cout << "sp2.get() = " << sp2.get() << endl;
    cout << "pInt = " << pInt << endl;
    cout << "sp2.use_count() = " << sp2.use_count() << endl;

#if 1
    cout << endl;
    shared_ptr<int> sp3(new int(20));
    cout << "*sp3 = " << *sp3 << endl;
    cout << "sp3.get() = " << sp3.get() << endl;
    cout << "pInt = " << pInt << endl;
    cout << "sp3.use_count() = " << sp3.use_count() << endl;

    cout << endl  << "执行赋值操作sp3 = sp" << endl;
    sp3 = sp;
    cout << "*sp3 = " << *sp3 << endl;
    cout << "sp3.get() = " << sp3.get() << endl;
    cout << "pInt = " << pInt << endl;
    cout << "sp3.use_count() = " << sp3.use_count() << endl;

    cout << endl;
    shared_ptr<Point> sp4(new Point(10, 20));
    vector<shared_ptr<Point>> vec;
    vec.push_back(sp4);
    /* vec.push_back(std::move(sp4)); */
    vec.push_back(shared_ptr<Point>(new Point(1, 3)));

    cout << endl;
    Point *pt = new Point(1, 2);
    vector<Point *> number;//不建议使用裸指针
    /* number.push_back(new Point(1, 2)); */
    number.push_back(pt);
    delete pt;

#endif
}
int main(int argc, char **argv)
{
    test();
    return 0;
}

