#include <iostream>
#include <iterator>
#include <vector>

using std::cout;
using std::endl;
using std::vector;


int main(int argc, char **argv)
{
    vector<int> number = {1, 3, 5, 7, 9};
    vector<int>::reverse_iterator rit = number.rbegin();

    for(; rit != number.rend(); ++rit)
    {
        cout << *rit << "   ";
    }
    cout << endl;
    return 0;
}

