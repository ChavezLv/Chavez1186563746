#include <iostream>
#include <iterator>
#include <vector>
#include <algorithm>

using std::cout;
using std::endl;
using std::ostream_iterator;
using std::istream_iterator;
using std::vector;
using std::copy;

void test()
{
    vector<int> number;
    cout << "111" << endl;
    istream_iterator<int> isi(std::cin);
    cout << "222" << endl;
    /* copy(isi, istream_iterator<int>(), number.begin());//error,vector的插入要使用push_back */
    copy(isi, istream_iterator<int>(), std::back_inserter(number));
    cout << "333" << endl;

    copy(number.begin(), number.end(), ostream_iterator<int>(cout, "\n"));
    cout << "444" << endl;
}

int main(int argc, char **argv)
{
    test();
    return 0;
}

