#include <iostream>
#include <iterator>
#include <vector>
#include <algorithm>

using std::cout;
using std::endl;
using std::ostream_iterator;
using std::vector;
using std::copy;

//cout 1 4 8 9 0 "\n"
void test()
{
    vector<int> number = {1, 4, 8, 9, 3};
    ostream_iterator<int> osi(cout, "\n");
    copy(number.begin(), number.end(), osi);
}

int main(int argc, char **argv)
{
    test();
    return 0;
}

