#include <iostream>
#include <iterator>
#include <vector>
#include <list>
#include <algorithm>

using std::cout;
using std::endl;
using std::back_inserter;
using std::back_insert_iterator;
using std::front_inserter;
using std::front_insert_iterator;
using std::inserter;
using std::insert_iterator;
using std::list;
using std::vector;
using std::copy;
using std::ostream_iterator;

void test()
{
    vector<int> numberVec = {1, 2, 5, 8};
    list<int> numberList = {10, 5, 7, 2, 5};
    copy(numberList.begin(), numberList.end(), back_insert_iterator<vector<int>>(numberVec));
    copy(numberVec.begin(), numberVec.end(), ostream_iterator<int>(cout, " "));
    cout << endl;

    cout << endl << endl;
    copy(numberVec.begin(), numberVec.end(), front_insert_iterator<list<int>>(numberList));
    copy(numberList.begin(), numberList.end(), ostream_iterator<int>(cout, "  "));
    cout << endl;
}
int main(int argc, char **argv)
{
    test();
    return 0;
}

