#include <iostream>

using std::cout;
using std::endl;

class Base
{
public:
    Base(long member = 0)
    : _member(member)
    {
        cout << "Base(long = 0) " << endl;
    }

    virtual
    void print()
    {
        cout << "Base::_member = " << _member << endl;
    }
/* private: */
protected:
    long _member;
};

class Derived
: public Base
{
public:
    Derived(long member1 = 0, long member2 = 0)
    : Base(member1)
    , _member(member2)
    {
        cout << "Derived(long = 0)" << endl;
    }

    /* void print(); */
    virtual
    /* void print() */
    void print(int x)
    {
        /* cout << "x = " << x << endl; */
        cout << "Base::_member = " << Base::_member << endl;
        cout << "_member = " << _member << endl;
    }
private:
    long _member;
};
int main(int argc, char **argv)
{
    Base base(10);
    Derived derived(20, 30);
    /* derived.print();//error */
    derived.print(1);
    /* derived.Base::print(); */

    return 0;
}

