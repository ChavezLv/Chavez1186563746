#include <string.h>
#include <iostream>

using std::cout;
using std::endl;

class Base
{
public:
    Base(const char *base)
    : _base(new char[strlen(base) + 1]())
    {
        cout << "Base(const char *)" << endl;
        strcpy(_base, base);
    }

    virtual
    void print()
    {
        cout << "Base::_base = " << _base << endl;
    }

    //基类的析构函数被设置为虚函数之后，派生类的析构函数
    //自动变为虚函数
    //
    //为什么可以这么做？编译器做了一个优化，因为析构函数对于任何
    //一个类只有一个，具有唯一性，编译就将析构函数改为destructor
    //,当基类将析构函数定义为虚函数之后，只要派生类定义了自己
    //析构函数，编译器就认为这是一种重写(重定义)

    //destructor
    virtual
    ~Base()
    {
        cout << "~Base()" << endl;
        if(_base)
        {
            delete [] _base;
            _base = nullptr;
        }
    }
private:
    char *_base;
};

class Derived
: public Base
{
public:
    Derived(const char *base, const char *derived)
    : Base(base)
    , _derived(new char[strlen(derived) + 1]())
    {
        cout << "Derived(const char *)" << endl;
        strcpy(_derived, derived);
    }

    void print() override
    {
        cout << "Derived::_derived = " << _derived << endl;
    }

    ~Derived()
    {
        cout << "~Derived()" << endl;
        if(_derived)
        {
            delete [] _derived;
            _derived = nullptr;
        }
    }

private:
    char *_derived;

};
int main(int argc, char **argv)
{
    Base *pbase = new Derived("hello", "world");
    pbase->print();

    /* delete dynamic_cast<Derived *>(pbase); */
    delete pbase;//1、析构函数
    //pbase->~Base();
    //pbase->~destructor

    return 0;
}

