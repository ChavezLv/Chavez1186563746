#include <iostream>

using std::cout;
using std::endl;

class Base
{
public:
    Base(long base = 0)
    : _base(base)
    {
        cout << "Base(long = 0)" << endl;
    }

    virtual
    void f()
    {
        cout << "virtual void Base::f()" << endl;
    }

    virtual
    void g()
    {
        cout << "virtual void Base::g()" << endl;
    }

    virtual
    void h()
    {
        cout << "virtual void Base::h()" << endl;
    }

    ~Base()
    {
        cout << "~Base()" << endl;
    }
private:
    long _base;
};

class Derived
: public Base
{
public:
    Derived(long base = 0, long derived = 0)
    : Base(base)
    , _derived(derived)
    {
        cout << "Derived(long = 0)" << endl;
    }

    virtual
    void f()
    {
        cout << "virtual void Derived::f()" << endl;
    }

    virtual
    void g()
    {
        cout << "virtual void Derived::g()" << endl;
    }

    virtual
    void h()
    {
        cout << "virtual void Derived::h()" << endl;
    }

    ~Derived()
    {
        cout << "~Derived()" << endl;
    }
private:
    long _derived;
};

int main(int argc, char **argv)
{
    //虚表是存在的，虚表存在于只读段,对于普通的单继承而言，一个类
    //只有一张虚表
    Derived derived(10, 20);
    printf("对象derived的地址 : %p\n", &derived);
    printf("对象derived的地址 : %p\n", (long *)&derived);
    /* printf("虚表的地址 : %p\n", *(long *)&derived);//ok */
    printf("虚表的地址 : %p\n", (long *)*(long *)&derived);
    printf("虚函数的地址 : %p\n", (long *)*(long *)*(long *)&derived);

    cout << endl << endl;
    typedef void (*Function)();
    Function pf;
    pf =  (Function)*((long *)*(long *)&derived);
    pf();
    printf("第一个虚函数的地址 : %p\n", pf);

    cout << endl;
    pf =  (Function)*((long *)*(long *)&derived + 1);
    pf();
    printf("第二个虚函数的地址 : %p\n", pf);

    cout << endl;
    pf =  (Function)*((long *)*(long *)&derived + 2);
    pf();
    printf("第三个虚函数的地址 : %p\n", pf);


    cout << endl;
    Derived derived2(100, 200);
    printf("对象derived2的地址 : %p\n", &derived2);
    printf("对象derived2的地址 : %p\n", (long *)&derived2);
    /* printf("虚表的地址 : %p\n", *(long *)&derived2);//ok */
    printf("虚表的地址 : %p\n", (long *)*(long *)&derived2);
    printf("虚函数的地址 : %p\n", (long *)*(long *)*(long *)&derived2);

    cout << endl;
    cout << "打印数据成员_base = " 
        <<   (long)*((long *)&derived + 1) << endl;

    cout << "打印数据成员_derived = " 
        <<   (long)*((long *)&derived + 2) << endl;


    return 0;
}

