#include <math.h>
#include <iostream>
#include <set>
#include <vector>

using std::cout;
using std::endl;
using std::multiset;
using std::vector;

template <typename Container>
void display(const Container &c)
{
    for(auto &elem : c)
    {
        cout << elem << "  ";
    }
    cout << endl;
}

void test()
{
    /* int arr[10] = {1, 3, 6, 8, 9, 2, 5, 5, 5, 6}; */
    /* multiset<int, std::less<int>>number(arr, arr + 10); */
    /* multiset<int, std::greater<int>>number(arr, arr + 10); */
    multiset<int> number = {1, 3, 6, 8, 9, 2, 5, 5, 5, 6};
    display(number);

    //multiset的查找
    size_t cnt1 = number.count(12);
    size_t cnt2 = number.count(5);
    cout << "cnt1 = " << cnt1 << endl;
    cout << "cnt2 = " << cnt2 << endl;

    cout << endl;
    auto it = number.find(9);
    if(it == number.end())
    {
        cout << "该元素不存在" << endl;
    }
    else
    {
        cout << "*it = " << *it <<endl;
    }

    //multiset的插入
    auto it2= number.insert(100);
    if(it2 == number.end())
    {
        cout << "插入失败" << endl;
    }
    else
    {
        cout << *it2 << endl;
    }

    vector<int> vec = {8, 39, 29, 10};
    number.insert(vec.begin(), vec.end());
    display(number);

    /* std::initializer_list<int> il = {19, 39, 20, 10}; */
    number.insert(std::initializer_list<int>{19, 39, 20, 10});
    display(number);

    cout << endl << endl;
    auto it3 = number.begin();
    ++it3;
    number.erase(it3);
    display(number);


    cout << endl << "bound的测试" << endl;
    auto it4 = number.lower_bound(5);
    auto it5 = number.upper_bound(5);
    cout << "*it4  =" << *it4 << endl;
    cout << "*it5  =" << *it5 << endl;
    while(it4 != it5)
    {
        cout << *it4 << " ";
        ++it4;
    }
    cout << endl;

    auto ret = number.equal_range(5);
    while(ret.first != ret.second)
    {
        cout << *ret.first << "     ";
        ++ret.first;
    }
    cout << endl;
}

class Point
{
public:
    Point(int ix = 0, int iy = 0)
    : _ix(ix)
    , _iy(iy)
    {
        /* cout << "Point(int = 0, int = 0)" << endl; */
    }

    double getDistance() const
    {
        return hypot(_ix, _iy);
    }

    int getX() const 
    {
        return _ix;
    }

    int getY() const
    {
        return _iy;
    }

    ~Point()
    {
        /* cout << "~Point()" << endl; */
    }

    friend std::ostream &operator<<(std::ostream &os, const Point &rhs);
private:
    int _ix;
    int _iy;
};

std::ostream &operator<<(std::ostream &os, const Point &rhs)
{
    os << "(" << rhs._ix 
      << "," << rhs._iy
      << ")";
    return os;
}
bool operator<(const Point &lhs, const Point &rhs)
{
    cout << "bool operator<(const Point &, const Point &)" << endl;
    if(lhs.getDistance() < rhs.getDistance())
    {
        return true;
    }
    else if(lhs.getDistance() == rhs.getDistance())
    {
        if(lhs.getX() < rhs.getX())
        {
            return true;
        }
        else if(lhs.getX() == rhs.getX())
        {
            if(lhs.getY() < rhs.getY())
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }
    else
    {
        return false;
    }
}

bool operator>(const Point &lhs, const Point &rhs)
{
    cout << "bool operator>(const Point &, const Point &)" << endl;
    if(lhs.getDistance() > rhs.getDistance())
    {
        return true;
    }
    else if(lhs.getDistance() == rhs.getDistance())
    {
        if(lhs.getX() > rhs.getX())
        {
            return true;
        }
        else if(lhs.getX() == rhs.getX())
        {
            if(lhs.getY() > rhs.getY())
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }
    else
    {
        return false;
    }
}

struct Comparetion
{
    bool operator()(const Point &lhs, const Point &rhs) const
    {
        cout << "struct Comparetion" << endl;
         if(lhs.getDistance() < rhs.getDistance())
         {
             return true;
         }
         else if(lhs.getDistance() == rhs.getDistance())
         {
             if(lhs.getX() < rhs.getX())
             {
                 return true;
             }
             else if(lhs.getX() == rhs.getX())
             {
                 if(lhs.getY() < rhs.getY())
                 {
                     return true;
                 }
                 else
                 {
                     return false;
                 }
             }

         }
         else
         {
             return false;
         }
    }
};
void test2()
{
    /* multiset<Point> number = { */
    /* multiset<Point, std::less<Point>> number = { */
    /* multiset<Point, std::greater<Point>> number = { */
    multiset<Point, Comparetion> number = {
        Point(1, 2),
        Point(1, -2),
        Point(-1, 2),
        Point(-1, 2),
        Point(10, 2),
        Point(0, 2),
        Point(0, 2),
        Point(-3, 2),
        Point(1, 2),
    };
    display(number);
}
int main(int argc, char **argv)
{
    test2();
    return 0;
}

