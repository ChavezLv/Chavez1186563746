#include <math.h>
#include <iostream>
#include <queue>
#include <vector>

using std::cout;
using std::endl;
using std::priority_queue;
using std::vector;

/* operator<(const A &lhs, const A &rhs); */
void test()
{
    //优先级队列底层使用的是堆排序，默认情况是一个大顶堆（std::less）
    //当有新的元素插进来的时候，就会用新的元素与堆顶去进行比较，
    //堆顶作为左边的操作数，新的元素作为了右操作数，堆顶与新的元素
    //去进行比较，如果满足std::less，就不用新的元素与堆顶进行置换，
    //如果不满足条件，堆顶依旧是新的堆顶
    priority_queue<int> number;

    vector<int> vec = {1, 5, 9, 7, 3, 6, 2};
    for(size_t idx = 0; idx != vec.size(); ++idx)
    {
        number.push(vec[idx]);
        cout << "优先级最高的元素 : " << number.top() << endl;
    }

    while(!number.empty())
    {
        cout << number.top() << "   ";
        number.pop();
    }
    cout << endl;

}

class Point
{
public:
    Point(int ix = 0, int iy = 0)
    : _ix(ix)
    , _iy(iy)
    {
        /* cout << "Point(int = 0, int = 0)" << endl; */
    }

    double getDistance() const
    {
        return hypot(_ix, _iy);
    }

    int getX() const 
    {
        return _ix;
    }

    int getY() const
    {
        return _iy;
    }

    ~Point()
    {
        /* cout << "~Point()" << endl; */
    }

    friend std::ostream &operator<<(std::ostream &os, const Point &rhs);
private:
    int _ix;
    int _iy;
};

std::ostream &operator<<(std::ostream &os, const Point &rhs)
{
    os << "(" << rhs._ix 
      << "," << rhs._iy
      << ")";
    return os;
}

bool operator<(const Point &lhs, const Point &rhs)
{
    /* cout << "bool operator<(const Point &, const Point &)" << endl; */
    if(lhs.getDistance() < rhs.getDistance())
    {
        return true;
    }
    else if(lhs.getDistance() == rhs.getDistance())
    {
        if(lhs.getX() < rhs.getX())
        {
            return true;
        }
        else if(lhs.getX() == rhs.getX())
        {
            if(lhs.getY() < rhs.getY())
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }

    }
    else
    {
        return false;
    }
}

bool operator>(const Point &lhs, const Point &rhs)
{
    /* cout << "bool operator>(const Point &, const Point &)" << endl; */
    if(lhs.getDistance() > rhs.getDistance())
    {
        return true;
    }
    else if(lhs.getDistance() == rhs.getDistance())
    {
        if(lhs.getX() > rhs.getX())
        {
            return true;
        }
        else if(lhs.getX() == rhs.getX())
        {
            if(lhs.getY() > rhs.getY())
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }

    }
    else
    {
        return false;
    }
}

struct Comparetion
{
    bool operator()(const Point &lhs, const Point &rhs) const
    {
        /* cout << "struct Comparetion" << endl; */
         if(lhs.getDistance() < rhs.getDistance())
         {
             return true;
         }
         else if(lhs.getDistance() == rhs.getDistance())
         {
             if(lhs.getX() < rhs.getX())
             {
                 return true;
             }
             else if(lhs.getX() == rhs.getX())
             {
                 if(lhs.getY() < rhs.getY())
                 {
                     return true;
                 }
                 else
                 {
                     return false;
                 }
             }
            else
            {
                return false;
            }

         }
         else
         {
             return false;
         }
    }
};
void test2()
{

    vector<Point> vec = {
        Point(1, 2),
        Point(1, 2),
        Point(1, -2),
        Point(-1, 2),
        Point(11, 2),
        Point(1, 12),
    };
    /* priority_queue<Point> number; */
    /* priority_queue<Point, vector<Point>, std::greater<Point>> number; */
    priority_queue<Point, vector<Point>, Comparetion> number;

    for(size_t idx = 0; idx != vec.size(); ++idx)
    {
        number.push(vec[idx]);
        cout << "优先级最高的元素 : " << number.top() << endl;
    }

    while(!number.empty())
    {
        cout << number.top() << "   ";
        number.pop();
    }
    cout << endl;

}
int main(int argc, char **argv)
{
    test2();
    return 0;
}

