#include "MyLogger.h"
#include <iostream>
#include <string>

using std::cout;
using std::endl;
using std::string;

string func(const char *msg)
{
    string s1 = string(__FILE__) + string(" ") + string(__FUNCTION__) 
        + string(" ") + string(std::to_string(__LINE__)) + string(" ") 
        +msg;
    return s1;
}
void test()
{
    /* Mylogger *ps1 = Mylogger::getInstance(); */
    /* ps1->error("hshsh"); */
    /* Mylogger::getInstance()->error("hahha"); */
    /* Mylogger::getInstance()->error(func("hahha").c_str()); */
    /* Mylogger::getInstance()->error(prefix("helloworld")); */
    /* Mylogger::getInstance()->warn(prefix("helloworld")); */
    /* Mylogger::getInstance()->info(prefix("helloworld")); */
    /* Mylogger::getInstance()->debug(prefix("helloworld")); */
    LogError("wuhan");
    const char *pstr = "hello";
    int number = 1;
    int value = 2;
    LogError("hello, %d, %s %d\n", number, pstr, value);

}

void test2()
{
    cout << __FILE__  << "   " << __FUNCTION__ << "  " << __LINE__ << endl;
}
int main(int argc, char **argv)
{
    test();
    return 0;
}

