#ifndef __MY_LPGGER_H__
#define __MY_LPGGER_H__
#include <log4cpp/Category.hh>

using namespace log4cpp;

class Mylogger
{
public:
    static Mylogger *getInstance();
    static void destroy();

    void warn(const char * msg);
    void error(const char * msg);
    void debug(const char * msg);
    void info(const char * msg);

private:
    Mylogger();
    ~Mylogger();
private:
    static Mylogger *_pInstance;
    Category &_mycat;

};

#define prefix(msg) (string(__FILE__) + string(" ") + string(__FUNCTION__) \
        + string(" ") + string(std::to_string(__LINE__)) + string(" ") \
        + msg).c_str()

#define LogError(msg)  Mylogger::getInstance()->error(prefix(msg))
#define LogInfo(msg)  Mylogger::getInstance()->info(prefix(msg))
#define LogWarn(msg)  Mylogger::getInstance()->warn(prefix(msg))
#define LogDebug(msg)  Mylogger::getInstance()->debug(prefix(msg))

#endif
